FORMATION_SCHEMES = {
    "I-FORM": {"QB": 1, "RB": 1, "WR": 2, "TE": 1, "LT": 1, "LG": 1, "C": 1, "RG": 1, "RT": 1},
    "SINGLEBACK": {"QB": 1, "RB": 1, "WR": 2, "TE": 2, "LT": 1, "LG": 1, "C": 1, "RG": 1, "RT": 1},
    "3WR": {"QB": 1, "RB": 1, "WR": 3, "TE": 1, "LT": 1, "LG": 1, "C": 1, "RG": 1, "RT": 1},
    "4WR": {"QB": 1, "RB": 1, "WR": 4, "TE": 0, "LT": 1, "LG": 1, "C": 1, "RG": 1, "RT": 1},
    "2TE": {"QB": 1, "RB": 1, "WR": 2, "TE": 2, "LT": 1, "LG": 1, "C": 1, "RG": 1, "RT": 1},
    "SHOTGUN": {"QB": 1, "RB": 1, "WR": 3, "TE": 1, "LT": 1, "LG": 1, "C": 1, "RG": 1, "RT": 1},
    "EMPTY": {"QB": 1, "RB": 0, "WR": 5, "TE": 0, "LT": 1, "LG": 1, "C": 1, "RG": 1, "RT": 1},
    "WILDCAT": {"QB": 0, "RB": 2, "WR": 2, "TE": 1, "LT": 1, "LG": 1, "C": 1, "RG": 1, "RT": 1}
}

DEFENSIVE_SCHEMES = {
    "4-3":   {"DL": 4, "LB": 3, "CB": 2, "S": 2},
    "3-4":   {"DL": 3, "LB": 4, "CB": 2, "S": 2},
    "Nickel": {"DL": 4, "LB": 2, "CB": 3, "S": 2},
    "Dime":   {"DL": 4, "LB": 1, "CB": 4, "S": 2},
    "Quarter": {"DL": 3, "LB": 1, "CB": 6, "S": 1}
}