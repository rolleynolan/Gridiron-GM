import random
from datetime import datetime, timedelta
from gridiron_gm.engine.core.player import Player

def generate_initial_college_db(num_per_class=300):
    """
    Generates an initial pool of college players across all classes (Freshman to Senior).
    """
    college_db = []
    for year in range(1, 5):  # 1: Freshman, 2: Sophomore, etc.
        for _ in range(num_per_class):
            player = generate_college_player(year)
            college_db.append(player)
    return college_db
def generate_valid_jersey_number(position):
    position_ranges = {
        'QB': range(0, 20),
        'RB': list(range(0, 50)) + list(range(20, 50)),
        'WR': list(range(0, 50)) + list(range(80, 90)),
        'TE': list(range(0, 50)) + list(range(80, 90)),
        'OL': range(50, 80),
        'DL': list(range(50, 80)) + list(range(90, 100)),
        'LB': list(range(0, 60)) + list(range(90, 100)),
        'CB': range(0, 50),
        'S': range(0, 50),
        'K': range(0, 20),
        'P': range(0, 20)
    }
    return random.choice(position_ranges.get(position, range(1, 100)))

def generate_college_player(year_in_college):
    """
    Create a Player object simulating a college player at a specific year level.
    """
    name = f"Player{random.randint(1000, 9999)}"
    position = random.choice(['QB', 'RB', 'WR', 'TE', 'OL', 'DL', 'LB', 'CB', 'S', 'K', 'P'])
    dob = datetime.now() - timedelta(days=365 * (18 + year_in_college))
    with open('data/fbs_colleges.txt', 'r') as f:
        colleges = [line.strip() for line in f if line.strip()]
    college = random.choice(colleges)
    with open('data/cities.txt', 'r') as f:
        cities = [line.strip() for line in f if line.strip()]
    birth_location = random.choice(cities)
    jersey_number = generate_valid_jersey_number(position)
    overall = int(random.gauss(70, 7))  # Bell curve with mean=70, std dev=7
    overall = max(40, min(overall, 85))  # Restrict to a realistic collegiate range where most players are below pro-ready thresholds range
 
 # Assign development curve and potential
    dev_curves = ['early', 'normal', 'late', 'flat']
    dev_weights = [0.2, 0.55, 0.2, 0.05]  # most are normal, few are flat or elite
    player.dev_curve = random.choices(dev_curves, weights=dev_weights, k=1)[0]

     # Assign true potential independently
    player.potential = int(random.gauss(75, 7))
    player.potential = max(50, min(player.potential, 99))  # Clamp to realistic range

    # Dev rate within small variation
    player.dev_rate = round(random.uniform(0.9, 1.1), 2)
    player = Player(name, position, 18 + year_in_college, dob, college, birth_location, jersey_number, overall)
    player.year_in_college = year_in_college
    return player