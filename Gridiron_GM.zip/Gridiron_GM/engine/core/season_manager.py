import os
import json
import random
from datetime import timedelta
from engine.core.standings_manager import StandingsManager
from engine.simulation.game_sim_engine import GameSimEngine
from engine.core.fatigue_manager import FatigueManager
from engine.playoffs.playoff_bracket import maybe_generate_playoffs
from engine.schedule.generate_schedule import generate_schedule
from engine.schedule.generate_schedule import generate_schedule_files_if_missing



class SeasonManager:
    def __init__(self, calendar, league, save_name="test_league"):
        self.calendar = calendar
        self.league = league
        self.save_name = save_name
        self.draft_day = None
        self.playoffs_generated = False

        from engine.schedule.generate_schedule import generate_schedule_files_if_missing

        # Load or generate schedule and results
        schedule_by_week, results_by_week = generate_schedule_files_if_missing(save_name=save_name)

        # Compute last scheduled day for each week
        self.last_scheduled_day_for_week = {
            str(week): (
                max(self.calendar.DAYS_OF_WEEK.index(game["day"].strip().capitalize()) for game in games)
                if games else -1
            )
            for week, games in schedule_by_week.items()
        }

        # Assign schedule context to calendar
        self.calendar.set_schedule_context(
            schedule_by_week=schedule_by_week,
            results_by_week=results_by_week,
            last_scheduled_day_for_week=self.last_scheduled_day_for_week
        )

        # Initialize standings
        self.standings_manager = StandingsManager(self.calendar, league, save_name)

        # Debug: playoff trigger visibility
        print("Checking playoff trigger: current_week =", self.calendar.current_week)
        print("Last scheduled day for week 22 =", self.last_scheduled_day_for_week.get("22"))

    def advance_day(self):
        info = self.calendar.get_display_info()
        print(f"\n=== {info['Label']} — {info['Day of Week']}, {info['Date']} ===")
        self.calendar.advance_day()
        if self.calendar.current_day in ["sunday", "monday", "thursday", "saturday"]:
            self.simulate_nfl_games()
            print(f"[DEBUG] Today is {self.calendar.current_day}")

        self.recover_fatigue()

        week_key = str(self.calendar.current_week)
        if (
            self.calendar.current_week == 22 and
            self.calendar.current_day_index == self.last_scheduled_day_for_week.get(week_key)
        ):
            from engine.playoffs.playoff_bracket import maybe_generate_playoffs
            maybe_generate_playoffs(self.calendar.current_year, self.standings_manager, self.save_name)

        
        


    def simulate_nfl_games(self):
        week = self.calendar.current_week
        today = self.calendar.get_current_day().lower()
        games = self.get_schedule_for_week(week)
        print(f"[DEBUG] Simulating games on {today} of Week {week}")

        playoff_rounds = {
            23: "Wildcard",
            24: "Divisional",
            25: "Conference",
            26: "Super Bowl"
        }

        if not games:
            print(f"[Week {week}] No scheduled games.")
            return

        todays_games = [g for g in games if g["day"].strip().lower() == today]
        print(f"[DEBUG] Found {len(todays_games)} games for {today.title()} of Week {week}")

        if not todays_games:
            print(f"[{today}] No games scheduled today.")
            return

        results = self.load_results(self.calendar.current_date.year)
        existing_ids = {r["game_id"] for r in results.get(str(week), []) if "game_id" in r}

        for game in todays_games:
            if game.get("game_id") in existing_ids:
                continue
            if self.is_user_game(game["home"], game["away"]):
                print(f"[!] Auto-simming user game: {game['home']} vs {game['away']} ({game['day']} {game['kickoff']})")

            result = self.simulate_game(game["home"], game["away"], game["kickoff"], game["day"])

            if self.calendar.current_week in playoff_rounds:
                result["round"] = playoff_rounds[self.calendar.current_week]

            result["game_id"] = game["game_id"]
            print(f"{result['home']} {result['home_score']} - {result['away_score']} {result['away']} ({result['day']} {result['kickoff']})")

            results.setdefault(str(week), []).append(result)
            self.standings_manager.update_from_result(result)
            self.save_results(self.calendar.current_date.year, results)
            with open(f"saves/{self.save_name}/results_{self.calendar.current_date.year}.json", "w") as f:
                json.dump(results, f, indent=2)
            self.standings_manager.save_standings()
            self.calendar.results_by_week = results

    def get_schedule_for_week(self, week):
        path = f"saves/{self.save_name}/schedule_by_week.json"
        if not os.path.exists(path):
            return []
        with open(path, "r") as f:
            all_schedules = json.load(f)
        return all_schedules.get(str(week), [])

    def simulate_game(self, home, away, kickoff, day):
        game_id = f"{away}@{home}-{self.calendar.current_week}"
        engine = GameSimEngine(home, away, self.calendar.current_week, game_id, save_name=self.save_name)
        result = engine.simulate()
        result["kickoff"] = kickoff
        result["day"] = day
        return result


    def is_user_game(self, home, away):
        for team in self.league.get("teams", []):
            if team["abbreviation"] in [home, away] and team.get("user_controlled", False):
                return True
        return False

    def sim_to_week(self, target_week):
        print(f"[SIM] Simulating to end of Week {target_week}...")
        while True:
            prev_week = self.calendar.current_week
            halted = self.advance_day()  # ✅ capture return value

            if halted:
                break  # ✅ Stop sim when playoff bracket was generated

            if self.calendar.current_week < prev_week:
                print("[SIM] Calendar rolled over to new season. Stopping sim.")
                break

            if self.calendar.current_week > target_week or (
                self.calendar.current_week == target_week and self.calendar.current_day_index > 1
            ):
                break






    def sim_to_date(self, target_date):
        print(f"[SIM] Simulating to date {target_date}...")
        while self.calendar.current_date < target_date:
            self.advance_day()

    def sim_to_day_index(self, target_index):
        print(f"[SIM] Simulating to day index {target_index}...")
        while self.calendar.current_day_index < target_index:
            self.advance_day()

    def load_results(self, year):
        path = f"saves/{self.save_name}/history/season_{year}_results.json"
        return json.load(open(path)) if os.path.exists(path) else {}

    def save_results(self, year, results):
        os.makedirs(f"saves/{self.save_name}/history", exist_ok=True)
        path = f"saves/{self.save_name}/history/season_{year}_results.json"
        with open(path, "w") as f:
            json.dump(results, f, indent=2)

    def handle_daily_morale(self):
        print("Running morale updates...")

    def recover_fatigue(self):
        for team in self.league.get("teams", []):
            context = "bye_week" if self.calendar.season_phase == "Offseason" else "in_play"
            FatigueManager.bulk_recover(team, context)

    def run_combine_day(self):
        print(f"Evaluating players for Combine Day ({self.calendar.current_date})...")

    def run_draft_day(self):
        self.draft_day = (self.draft_day or 0) + 1
        print(f"Running Draft Day {self.draft_day} — {self.calendar.current_date}")

    def is_important_event_tomorrow(self):
        tomorrow = self.calendar.current_date + timedelta(days=1)
        return self.calendar.is_draft_window() or tomorrow.weekday() == 1