import random
from datetime import datetime, timedelta
from engine.core.player_progression import progress_players


def simulate_week(game_world):
    teams = game_world["teams"]
    calendar = game_world["calendar"]
    season_phase = calendar.season_phase

    if not teams:
        print("\nNo teams available to simulate.")
        return

    print("\n--- Week Results ---")

    if season_phase == "Regular Season":
        matchups = simulate_regular_season_week(teams)
        record_weekly_results(game_world, calendar.current_week - 1, matchups)
        check_end_of_regular_season(game_world)
    elif season_phase == "Playoffs":
        simulate_playoff_week(game_world)
        check_end_of_playoffs(game_world)
    elif season_phase == "Offseason":
        handle_offseason_week(game_world)

    else:
        print(f"\nNo games scheduled during {season_phase} phase.")
    
    calendar.advance_week()
    print(f"\nGames completed. Current Date: {calendar.get_current_date()}")


def simulate_regular_season_week(teams):
    scheduled = teams[:]
    random.shuffle(scheduled)

    weekly_matchups = []

    for i in range(0, len(scheduled), 2):
        if i + 1 >= len(scheduled):
            print(f"{scheduled[i].city} {scheduled[i].name} has a bye week.")
            continue

        team1 = scheduled[i]
        team2 = scheduled[i + 1]

        score1 = random.randint(10, 40)
        score2 = random.randint(10, 40)

        if score1 > score2:
            team1.team_record["wins"] += 1
            team2.team_record["losses"] += 1
            result = f"{team1.city} {team1.name} beat {team2.city} {team2.name} ({score1}-{score2})"
        elif score2 > score1:
            team2.team_record["wins"] += 1
            team1.team_record["losses"] += 1
            result = f"{team2.city} {team2.name} beat {team1.city} {team1.name} ({score2}-{score1})"
        else:
            team1.team_record["ties"] += 1
            team2.team_record["ties"] += 1
            result = f"{team1.city} {team1.name} tied with {team2.city} {team2.name} ({score1}-{score2})"

        print(result)

        weekly_matchups.append({
            "home_name": f"{team1.city} {team1.name}",
            "home_score": score1,
            "away_name": f"{team2.city} {team2.name}",
            "away_score": score2,
        })

    return weekly_matchups


def simulate_playoff_week(game_world):
    teams = game_world["teams"]
    calendar = game_world["calendar"]

    if len(teams) <= 1:
        if teams:
            champion = teams[0]
            print(f"\n\U0001F3C6 {champion.city} {champion.name} wins the Super Bowl! \U0001F3C6")
        else:
            print("\nNo teams left. Playoffs error.")

        calendar.season_phase = "Offseason"
        print("\nSeason Phase has advanced to Offseason.")
        return

    playoff_teams = sorted(teams, key=lambda t: (t.team_record["wins"], -t.team_record["losses"]), reverse=True)

    winners = []

    for i in range(0, len(playoff_teams), 2):
        if i + 1 >= len(playoff_teams):
            winners.append(playoff_teams[i])
            continue

        team1 = playoff_teams[i]
        team2 = playoff_teams[i + 1]

        score1 = random.randint(14, 35)
        score2 = random.randint(14, 35)

        if score1 > score2:
            winners.append(team1)
            team1.team_record["wins"] += 1
            team2.team_record["losses"] += 1
            result = f"{team1.city} {team1.name} beat {team2.city} {team2.name} ({score1}-{score2})"
        else:
            winners.append(team2)
            team2.team_record["wins"] += 1
            team1.team_record["losses"] += 1
            result = f"{team2.city} {team2.name} beat {team1.city} {team1.name} ({score2}-{score1})"

        print(result)

    game_world["teams"] = winners


def check_end_of_regular_season(game_world):
    calendar = game_world["calendar"]
    if calendar.current_week > 18:
        print("\nRegular Season Complete! Moving to Playoffs...")

        all_teams = game_world["all_teams"]
        playoff_teams = sorted(all_teams, key=lambda t: t.team_record["wins"], reverse=True)[:4]

        game_world["teams"] = playoff_teams
        calendar.season_phase = "Playoffs"
        game_world["playoff_round"] = 1


def check_end_of_playoffs(game_world):
    calendar = game_world["calendar"]
    if "playoff_round" not in game_world:
        game_world["playoff_round"] = 1
    else:
        game_world["playoff_round"] += 1

    if game_world["playoff_round"] > 3:
        print("\nPlayoffs Complete! Moving to Offseason...")
        calendar.season_phase = "Offseason"

        progress_players(game_world["all_teams"])

        from engine.core.college_player_generator import generate_college_player
        from engine.core.offseason_manager import reset_offseason
        reset_offseason(game_world, generate_college_player)


def record_weekly_results(game_world, week_index, matchups):
    if "weekly_results" not in game_world:
        game_world["weekly_results"] = {}

    formatted = []
    for m in matchups:
        formatted.append({
            "home_team": {"name": m["home_name"], "score": m["home_score"]},
            "away_team": {"name": m["away_name"], "score": m["away_score"]},
        })

    game_world["weekly_results"][week_index] = formatted

def handle_offseason_week(game_world):
    calendar = game_world["calendar"]
    subphase = calendar.offseason_subphase

    print(f"\n[OFFSEASON] Week {calendar.current_week}: {subphase}")

    if subphase == "Combine":
        print("→ Combine evaluations running...")

    elif subphase == "Free Agency":
        print("→ Free agency negotiations in progress...")

    elif subphase == "Draft":
        print("→ The draft window is open. You may run the draft manually.")

    elif subphase == "Rookie Camp":
        print("→ Rookie camp is underway.")

    elif subphase == "Minicamp":
        print("→ Minicamp activities taking place.")

    elif subphase == "Dead Period":
        print("→ League is in dead period. No activity this week.")

    # Season rollover
    # Season rollover
    # Track how many weeks we've spent in Dead Period
    if not hasattr(calendar, "dead_period_counter"):
        calendar.dead_period_counter = 0

    if subphase == "Dead Period":
        calendar.dead_period_counter += 1
    else:
        calendar.dead_period_counter = 0  # Reset counter when not in dead period

    # Reset only after 3 weeks of Dead Period
    if subphase == "Dead Period" and calendar.dead_period_counter >= 3:
        print("\n[RESET] Offseason complete. Advancing to new season...")
        from engine.core.college_player_generator import generate_college_player
        from engine.core.offseason_manager import reset_offseason
        reset_offseason(game_world, generate_college_player)
        calendar.dead_period_counter = 0  # Reset for the new season



