class SubstitutionManagerV2:
    def __init__(self, depth_chart):
        self.depth_chart = depth_chart

    def get_active_lineup_with_bench_log(self, formation, offense, fatigue_log, scheme):
        selected_rbs = []  # Ensure default definition
        selected_wrs = []
        selected_tes = []
        bench_log = []
        active_lineup = []
        log = []
        rb_count = formation.get("RB", 0)
        rbs = offense.get("depth_chart", {}).get("RB", [])
        
        if rbs:
            # Always select RBs even if fatigued
            rbs_sorted = sorted(rbs, key=lambda p: p.fatigue)
            selected_rbs = rbs_sorted[:rb_count]
            for p in selected_rbs:
                fatigue_log.append(f"[SUB] RB: fallback or rotated in {p.name} (fatigue {p.fatigue:.2f})")
                log.append(p)
            print(f"[DEBUG] RBs considered: {[f'{p.name} ({p.fatigue:.2f})' for p in rbs]} → selected: {[p.name for p in selected_rbs]}")
            active_lineup.extend(selected_rbs)
        else:
            fatigue_log.append("[SUB] RB: No RBs in depth chart")

                # Select WRs
        wr_count = formation.get("WR", 0)
        wrs = offense.get("depth_chart", {}).get("WR", [])
        
        if wrs:
            wrs_sorted = sorted(wrs, key=lambda p: p.fatigue)
            selected_wrs = wrs_sorted[:wr_count]
            for p in selected_wrs:
                fatigue_log.append(f"[SUB] WR: fallback or rotated in {p.name} (fatigue {p.fatigue:.2f})")
                log.append(p)
            print(f"[DEBUG] WRs considered: {[f'{p.name} ({p.fatigue:.2f})' for p in wrs]} → selected: {[p.name for p in selected_wrs]}")
            active_lineup.extend(selected_wrs)
        else:
            fatigue_log.append("[SUB] WR: No WRs in depth chart")

        # Select TEs
        te_count = formation.get("TE", 0)
        tes = offense.get("depth_chart", {}).get("TE", [])
        
        if tes:
            tes_sorted = sorted(tes, key=lambda p: p.fatigue)
            selected_tes = tes_sorted[:te_count]
            for p in selected_tes:
                fatigue_log.append(f"[SUB] TE: fallback or rotated in {p.name} (fatigue {p.fatigue:.2f})")
                log.append(p)
            print(f"[DEBUG] TEs considered: {[f'{p.name} ({p.fatigue:.2f})' for p in tes]} → selected: {[p.name for p in selected_tes]}")
            active_lineup.extend(selected_tes)
        else:
            fatigue_log.append("[SUB] TE: No TEs in depth chart")

        lineup = {}
        bench_log = []

        for position, count in scheme.items():
            depth_list = self.depth_chart.get(position, [])
            chosen = []

            for i in range(count):
                if i < len(depth_list):
                    player = depth_list[i]
                    if player.fatigue >= 0.9 and len(depth_list) > i + 1:
                        backup = depth_list[i + 1]
                        if backup.fatigue < 0.9:
                            chosen.append(backup)
                            bench_log.append(f"{position}: {player.name} → {backup.name}")
                        else:
                            chosen.append(player)
                    else:
                        chosen.append(player)

            for idx, player in enumerate(chosen, 1):
                key = f"{position}{idx}" if count > 1 else position
                lineup[key] = player

        return lineup, bench_log
