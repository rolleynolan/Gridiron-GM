import random

def progress_players(team_rosters):
    """
    Apply simple offseason progression to all players based on dev_curve, dev_rate, and potential.
    This function is safe to call once per season end.
    """
    for roster in team_rosters:
        for player in roster.players:
            # Pull key values
            overall = getattr(player, "true_overall", None)
            dev_curve = getattr(player, "dev_curve", "normal")
            dev_rate = getattr(player, "dev_rate", 1.0)
            potential = getattr(player, "potential", 80)

            if overall is None:
                continue  # Skip uninitialized players

            # Dev curve base deltas
            curve_delta = {
                "early": -1,
                "normal": 1,
                "late": 2,
                "flat": 0,
            }.get(dev_curve, 0)

            # Add a small random wiggle (±1)
            wiggle = random.choice([-1, 0, 1])

            # Final progression value
            delta = int((curve_delta + wiggle) * dev_rate)

            # Apply change
            new_overall = max(30, min(potential, overall + delta))
            player.true_overall = new_overall

            # Optional: debug log for testing
            if hasattr(player, "name"):
                print(f"[PROGRESS] {player.name}: {overall} → {new_overall} (curve={dev_curve}, rate={dev_rate})")
