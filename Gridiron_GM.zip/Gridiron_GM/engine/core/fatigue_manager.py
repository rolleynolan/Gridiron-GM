class FatigueManager:

    @staticmethod
    def recover(player, context="in_play", is_on_field=True):
        base_recovery = {
            "between_plays": 0.015,
            "on_sideline": 0.08,
            "halftime": 0.5,
            "timeout": 0.05,
            "bye_week": 1.0,
            "post_game": 0.3,
        }.get(context, 0.015)

        if is_on_field and context == "in_play":
            recovery = 0.01
        elif not is_on_field:
            recovery = base_recovery
        else:
            recovery = base_recovery

        player["fatigue"] = max(0.0, player.get("fatigue", 0.0) - recovery)

    @staticmethod
    def bulk_recover(team, context="in_play", on_field_players=None):
        # Check if team is a dict (sim context)
        if isinstance(team, dict):
            for player in team.get("roster", []):
                FatigueManager.recover(player, context)
        else:
            for pos_list in team.depth_chart.values():
                for player in pos_list:
                    is_on_field = on_field_players and player in on_field_players
                    FatigueManager.recover(player, context=context, is_on_field=is_on_field)

