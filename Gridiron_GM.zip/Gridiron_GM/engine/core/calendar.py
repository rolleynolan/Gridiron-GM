
from datetime import date, timedelta, datetime

class Calendar:
    DAYS_OF_WEEK = ["Monday", "Tuesday", "Wednesday", "Thursday", "Friday", "Saturday", "Sunday"]
    START_OF_NFL_YEAR_WEEK = 41

    def __init__(self):
        self.current_year = 2025
        self.current_date = self.get_nfl_week1_start(self.current_year)
        self.season_phase = "Preseason"
        self.playoff_subphase = None
        self.offseason_subphase = None
        self._setup_phase_boundaries()
        self.nfl_week1_start_date = self.get_nfl_week1_start(self.current_year)

    @property
    def internal_phase_week(self):
        for phase, (start_week, _) in self.phase_boundaries.items():
            if self.season_phase == phase:
                return self.current_week - start_week + 1
        return 1

    
    def set_schedule_context(self, schedule_by_week, results_by_week, last_scheduled_day_for_week, regular_season_weeks=18):
        self.schedule_by_week = schedule_by_week
        self.results_by_week = results_by_week
        self.regular_season_weeks = regular_season_weeks
        self.last_scheduled_day_for_week = {
            week: max(
                self.DAYS_OF_WEEK.index(game["day"].strip().capitalize())
                for game in games
            ) if games else -1

            for week, games in schedule_by_week.items()
        }

        print("Last scheduled day for each week:", self.last_scheduled_day_for_week)


    
    def _setup_phase_boundaries(self):
        self.phase_boundaries = {
            "Preseason": (1, 4),
            "Regular Season": (5, 22),
            "Playoffs": (23, 26),
            "Offseason": (27, 52),
        }

        self.playoff_subphases = {
            23: "Wild Card Round",
            24: "Divisional Round",
            25: "Conference Championships",
            26: "Gridiron Bowl"
        }

        self.offseason_subphases = {
            (27, 28): "Postseason Wrap-Up",
            (29, 30): "Combine",
            (31, 34): "Free Agency",
            (35, 36): "Rookie Camp",
            (37, 40): "Minicamp",
            (41, 52): "Dead Period"
        }

    def get_nfl_week1_start(self, year):
        sept1 = date(year, 9, 1)
        labor_day = sept1 + timedelta(days=(7 - sept1.weekday()) % 7)
        return labor_day + timedelta(days=1)

    def get_current_day(self):
        return self.DAYS_OF_WEEK[self.current_date.weekday()]

    
    @property
    def current_week(self):
        # Ensure both are date objects
        current = self.current_date.date() if isinstance(self.current_date, datetime) else self.current_date
        start = self.nfl_week1_start_date
        delta = current - start
        week_number = max(1, delta.days // 7 + 5)  # +5 shifts Week 1 to align with real NFL mid-Aug
        return week_number


    @property
    def current_day_index(self):
        return self.current_date.weekday()

    @property
    def current_day(self):
        return self.current_date.strftime("%A")

    def get_display_info(self):
        return {
            "Year": self.current_year,
            "Phase": self.season_phase,
            "Label": self.get_current_label(),
            "Day of Week": self.current_day,
            "Date": self.current_date
        }

    def get_week_label(self):
        if self.current_week <= 3:
            return f"Preseason Week {self.current_week}"
        elif self.current_week == 4:
            return "Bye Week"
        elif 5 <= self.current_week <= 22:
            return f"Regular Season Week {self.current_week - 4}"
        elif 23 <= self.current_week <= 25:
            return f"Playoffs Week {self.current_week - 22}"
        else:
            return "Offseason"


    
    def get_current_label(self):
        if self.current_week <= 3:
            return f"Preseason Week {self.current_week}"
        elif self.current_week == 4:
            return "Bye Week"
        elif 5 <= self.current_week <= 22:
            return f"Regular Season Week {self.current_week - 4}"
        elif 23 <= self.current_week <= 25:
            return f"Playoffs Week {self.current_week - 22}"
        else:
            return "Offseason"


    def advance_day(self):
        self.current_date += timedelta(days=1)
        self.update_phase()

    def update_phase(self):
        for phase, (start, end) in self.phase_boundaries.items():
            if start <= self.current_week <= end:
                self.season_phase = phase
                break

        if self.season_phase == "Playoffs":
            self.playoff_subphase = self.playoff_subphases.get(self.current_week, None)
            self.offseason_subphase = None
        elif self.season_phase == "Offseason":
            self.playoff_subphase = None
            self.offseason_subphase = self.get_offseason_subphase()
        else:
            self.playoff_subphase = None
            self.offseason_subphase = None

    def get_offseason_subphase(self):
        for (start, end), name in self.offseason_subphases.items():
            if start <= self.current_week <= end:
                return name
        return None

    def is_draft_window(self):
        def last_weekday_of_month(year, month, weekday):
            last_day = date(year, month + 1, 1) - timedelta(days=1) if month < 12 else date(year, 12, 31)
            while last_day.weekday() != weekday:
                last_day -= timedelta(days=1)
            return last_day
        thursday = last_weekday_of_month(self.current_year, 4, 3)
        return self.current_date == thursday or self.current_date == thursday + timedelta(days=1) or self.current_date == thursday + timedelta(days=2)

    def get_offseason_subphase(self):
        for (start, end), name in self.offseason_subphases.items():
            if start <= self.current_week <= end:
                return name
        return None

    def should_advance_week(self, ignore_game_check=False):
        return self.current_day_index == 1
