def reset_offseason(game_world, draft_class_generator, num_prospects=64):
    """
    Reset game state at the end of the season:
    - Reset team records
    - Age players
    - Generate new draft class
    - Reset calendar for new season
    """
    # 1. Reset team records and age players
    for team in game_world["all_teams"]:
        team.team_record = {"wins": 0, "losses": 0, "ties": 0}
        for player in team.players:
            if hasattr(player, "age"):
                player.age += 1
            if hasattr(player, "experience"):
                player.experience += 1

    # 2. Generate new draft pool
    new_draft_pool = [draft_class_generator(year_in_college=3) for _ in range(num_prospects)]
    game_world["draft_pool"] = new_draft_pool

    # 3. Reset calendar (use Calendar object methods/attributes)
    calendar = game_world["calendar"]
    calendar.start_new_year()
    calendar.current_week = 1
    calendar.internal_phase_week = 1
    calendar.season_phase = "Preseason"
    calendar.draft_completed = False  # reset draft flag if used

    print("\n[RESET] Offseason complete. New draft class generated. Season reset.")
    return game_world
