from engine.core.substitution_manager import SubstitutionManagerV2
from collections import defaultdict
from engine.constants.formations import FORMATION_SCHEMES


class DepthChartManager:
    def __init__(self, team):
        self.team = team
        self.depth_chart = {
            "QB": [], "RB": [], "WR": [], "TE": [],
            "OL": [], "DL": [], "LB": [], "CB": [],
            "S": [], "K": [], "P": []
        }

    def get_starters_by_scheme(self, scheme):
        """
        Return a dictionary of starters based on a positional scheme.
        """
        starters = {}
        for position, count in scheme.items():
            if position in self.depth_chart:
                starters[position] = self.depth_chart[position][:count]
            else:
                starters[position] = []
        return starters

    def auto_assign_depth_chart(self):
        for position in self.depth_chart:
            players = [p for p in self.team["roster"] if hasattr(p, "position") and p.position == position]
            self.depth_chart[position] = sorted(players, key=lambda p: p.overall, reverse=True)

    def get_starters_by_scheme(self, scheme):
        starters = {}
        for position, count in scheme.items():
            if position in self.depth_chart:
                starters[position] = self.depth_chart[position][:count]
            else:
                starters[position] = []
        return starters

    def get_fatigue_aware_starters(self, package):
        scheme = FORMATION_SCHEMES.get(package, {"QB": 1, "RB": 1, "WR": 2, "TE": 1, "OL": 5})
        sub_manager = SubstitutionManagerV2(self.depth_chart)
        lineup, _ = sub_manager.get_active_lineup_with_bench_log(scheme)
        return lineup


    def print_depth_chart(self):
        print(f"Depth Chart for {self.team.name}")
        for position, players in self.depth_chart.items():
            print(f"{position}:")
            for i, player in enumerate(players):
                print(f"  {i+1}. {player.name} (OVR: {player.overall})")

def generate_depth_chart(roster):
    depth_chart = defaultdict(list)
    for player in roster:
        pos = player.get("position")
        if pos:
            depth_chart[pos].append(player)

    for pos in depth_chart:
        depth_chart[pos] = sorted(
            depth_chart[pos],
            key=lambda p: p.get("overall", 0),
            reverse=True
        )

    return {
        "QB": depth_chart["QB"][:1],
        "RB": depth_chart["RB"][:2],
        "FB": depth_chart["FB"][:1],
        "WR": depth_chart["WR"][:4],
        "TE": depth_chart["TE"][:2],
        "LT": depth_chart["LT"][:1],
        "LG": depth_chart["LG"][:1],
        "C": depth_chart["C"][:1],
        "RG": depth_chart["RG"][:1],
        "RT": depth_chart["RT"][:1],
        "LE": depth_chart["LE"][:1],
        "RE": depth_chart["RE"][:1],
        "DT": depth_chart["DT"][:2],
        "LOLB": depth_chart["LOLB"][:1],
        "MLB": depth_chart["MLB"][:1],
        "ROLB": depth_chart["ROLB"][:1],
        "CB": depth_chart["CB"][:3],
        "FS": depth_chart["FS"][:1],
        "SS": depth_chart["SS"][:1],
        "K": depth_chart["K"][:1],
        "P": depth_chart["P"][:1],
    }
