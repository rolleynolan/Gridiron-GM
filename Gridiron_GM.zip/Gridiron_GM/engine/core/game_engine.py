import random
from collections import defaultdict
from engine.core.depth_chart_manager import generate_depth_chart
from engine.core.fatigue_manager import FatigueManager
from engine.constants.formations import FORMATION_SCHEMES


def inject_fatigue(team):
    for player in team.get("roster", []):
        if "fatigue" not in player:
            player["fatigue"] = 0.0

def apply_fatigue(player, base_cost):
    stamina = player.get("stamina", 70)
    fatigue_gain = base_cost * (100 / stamina) / 100
    player["fatigue"] = min(1.0, player.get("fatigue", 0.0) + fatigue_gain)
    return player["fatigue"]

def recover_fatigue(team, recovery=0.015):
    for player in team.get("roster", []):
        player["fatigue"] = max(0.0, player.get("fatigue", 0.0) - recovery)

def passive_line_fatigue(team, positions=("LT", "LG", "C", "RG", "RT"), cost=1.5):
    for player in team.get("roster", []):
        if player.get("position") in positions:
            apply_fatigue(player, cost)


def select_fresh_player(depth_chart_list, threshold=0.7, last_used=None):
    if not depth_chart_list:
        return {"name": "Unknown"}
    primary = depth_chart_list[0]
    selected = None
    for player in depth_chart_list:
        if player.get("fatigue", 0.0) < threshold:
            selected = player
            break
    selected = selected or primary
    if last_used and selected["name"] != last_used["name"]:
        selected["subbed_in"] = f"[SUB] {last_used['name']} (fatigue {last_used['fatigue']:.2f}) → {selected['name']}"
    return selected

def simulate_pass_play(qb, wr_list, depth):
    completion_chance = {"short": 0.8, "medium": 0.6, "deep": 0.4}[depth]
    max_yards = {"short": 10, "medium": 20, "deep": 40}[depth]

    receiver = select_fresh_player(wr_list)
    wr_name = receiver.name
    qb_name = qb.name

    apply_fatigue(qb, 2)
    apply_fatigue(receiver, 4 + {"short": 0, "medium": 1, "deep": 2}[depth] * 1.5)

    qb_fatigue = getattr(qb, "fatigue", 0.0)
    wr_fatigue = getattr(receiver, "fatigue", 0.0)
    penalty = 0.10 if max(qb_fatigue, wr_fatigue) > 0.9 else 0.05 if max(qb_fatigue, wr_fatigue) > 0.7 else 0.0
    completion_chance -= penalty

    is_complete = random.random() < completion_chance
    sub_log = getattr(receiver, "subbed_in", "")

    if is_complete:
        yards = random.randint(3, max_yards)
        log = f"{sub_log + ' ' if sub_log else ''}{qb_name} completed a {depth} pass to {wr_name} for {yards} yards"
        stats = {
            qb_name: {"pass_attempts": 1, "completions": 1, "pass_yards": yards},
            wr_name: {"receptions": 1, "rec_yards": yards}
        }
        time = random.randint(25, 40)
    else:
        yards = 0
        log = f"{sub_log + ' ' if sub_log else ''}{qb_name} attempted a {depth} pass to {wr_name} — incomplete"
        stats = {qb_name: {"pass_attempts": 1, "completions": 0}}
        time = random.randint(5, 10)

    return {"yards": yards, "log": log.strip(), "player_stats": stats, "seconds_burned": time}

def simulate_run_play(runner, gap):
    base_range = {"inside": (1, 6), "outside": (2, 12)}[gap]
    fatigue = getattr(runner, "fatigue", 0.0)
    penalty = 0.5 if fatigue > 0.9 else 0.3 if fatigue > 0.7 else 0.0
    reduced_max = int(base_range[1] * (1 - penalty))
    yards = random.randint(base_range[0], reduced_max)

    apply_fatigue(runner, 5 if gap == "inside" else 7)

    name = runner.name
    sub_note = f"{runner.subbed_in} " if hasattr(runner, "subbed_in") else ""
    log = f"{sub_note}{name} ran {gap} for {yards} yards"

    stats = {name: {"carries": 1, "rush_yards": yards}}
    time = random.randint(30, 45)

    return {"yards": yards, "log": log.strip(), "player_stats": stats, "seconds_burned": time}


def run_play(offense, defense, down, to_go, yardline, sub_manager, fatigue_log):
    package = offense.get("package", "standard")
    scheme = FORMATION_SCHEMES.get(package, {"QB": 1, "RB": 1, "WR": 2, "TE": 1, "OL": 5})
    formation = scheme.get("formation", {})  # make sure this extracts the actual formation
    lineup, sub_log = sub_manager.get_active_lineup_with_bench_log(formation, offense, fatigue_log, scheme)


    for p in lineup.values():
        players = p if isinstance(p, list) else [p]
        for player in players:
            FatigueManager.apply_play_fatigue(player, context="skill")  # or lineman/qb/etc. depending on role


    for log in sub_log:
        fatigue_log.append(f"[SUB] {log}")

    play_type = random.choice(["run", "pass"])
    play_result = {}

    if play_type == "run":
        # Attempt to locate an RB in lineup
        runner = lineup.get("RB1") or next((p for k, p in lineup.items() if hasattr(p, "position") and p.position == "RB"), None)

        if runner:
            yards = random.randint(2, 12)
            play_result = {
                "desc": f"{runner.name} ran for {yards} yards",
                "yards": yards
            }
        else:
            play_result = {"desc": "No RB available", "yards": 0}
    else:
        qb = lineup.get("QB")
        wr = lineup.get("WR1")
        if isinstance(qb, list):
            qb = qb[0] if qb else None
        if isinstance(wr, list):
            wr = wr[0] if wr else None
        if qb and wr:
            yards = random.randint(4, 25)
            complete = random.random() < 0.65
            if complete:
                play_result = {
                    "desc": f"{qb.name} completed a pass to {wr.name} for {yards} yards",
                    "yards": yards
                }
            else:
                play_result = {
                    "desc": f"{qb.name} attempted a pass to {wr.name} — incomplete",
                    "yards": 0
                }
        else:
            play_result = {"desc": "Missing QB or WR", "yards": 0}

    return play_result





def run_drive(offense, defense, sub_manager, fatigue_log):
    drive_log = []
    yards_to_go = 10
    yardline = 25
    down = 1
    time_remaining = 120  # average drive = 2 minutes
    drive_yards = 0
    score = 0
    player_stats = defaultdict(lambda: defaultdict(int))

    while time_remaining > 0 and yardline < 100:
        # Select a package randomly for now (can be strategy-based later)
        package = random.choice(["I-FORM", "3WR", "SINGLEBACK", "2TE", "SHOTGUN", "EMPTY", "WILDCAT"])
        scheme = FORMATION_SCHEMES.get(package, {"QB": 1, "RB": 1, "WR": 2, "TE": 1, "OL": 5})
        result = run_play(offense, defense, down, yards_to_go, yardline, sub_manager, fatigue_log)
        drive_log.append(f"[{package}] {result['desc']}")
        gain = result.get("yards", 0)
        drive_yards += gain
        yardline += gain
        time_remaining -= random.randint(10, 30)
        if gain >= yards_to_go:
            down = 1
            yards_to_go = 10
        else:
            down += 1
            yards_to_go -= gain
            if down > 4:
                drive_log.append("Turnover on downs")
                break

        if yardline >= 100:
            drive_log.append("Touchdown by " + offense["abbreviation"])
            score = 7
            break

    return {
        "log": drive_log,
        "score": score,
        "player_stats": player_stats
    }



def simulate_game(team_a, team_b, week):
    from engine.core.depth_chart_manager import DepthChartManager
    from engine.core.substitution_manager import SubstitutionManagerV2
    from collections import defaultdict
    import random
    
    # Ensure depth charts are generated for both teams
    for team in (team_a, team_b):
        if 'depth_chart' not in team:
            dcm = DepthChartManager(team)
            dcm.auto_assign_depth_chart()
            team['depth_chart'] = dcm.depth_chart

    game_log = []
    player_stats = defaultdict(lambda: defaultdict(int))
    fatigue_log = []

    # Setup depth chart and substitution manager
    depth_a = DepthChartManager(team_a)
    depth_a.auto_assign_depth_chart()
    sub_a = SubstitutionManagerV2(depth_a.depth_chart)

    depth_b = DepthChartManager(team_b)
    depth_b.auto_assign_depth_chart()
    sub_b = SubstitutionManagerV2(depth_b.depth_chart)

    # Initialize scores
    score = {
        team_a["abbreviation"]: 0,
        team_b["abbreviation"]: 0
    }

    # Possession order
    possessions = [team_a, team_b]
    random.shuffle(possessions)

    for i in range(12):  # 12 drives each (adjust as needed)
        offense = possessions[i % 2]
        defense = team_b if offense == team_a else team_a
        sub_mgr = sub_a if offense == team_a else sub_b

        drive_result = run_drive(offense, defense, sub_mgr, fatigue_log)
        game_log.extend(drive_result["log"])
        game_log.append("")

        score[offense["abbreviation"]] += drive_result["score"]

    # Optional: print fatigue log for debug
    game_log.append("== Fatigue Substitution Log ==")
    game_log.extend(fatigue_log)

    return {
        "home": team_a["abbreviation"],
        "away": team_b["abbreviation"],
        "home_score": score[team_a["abbreviation"]],
        "away_score": score[team_b["abbreviation"]],
        "log": game_log,
        "player_stats": player_stats,
        "fatigue_log": fatigue_log
    }



def choose_play_type(offense, down, yards_to_go):
    coordinator = offense.get("coordinator", {})
    style = coordinator.get("play_style", {})
    base_weights = style.get("base", {"run": 0.5, "pass": 0.5})
    special_weights = style.get("special", {"trick": 0.01})
    if random.random() < special_weights.get("trick", 0.01):
        return {
            "type": "trick",
            "style": "reverse",
            "formation": "Wildcat",
            "package": "goal_line"
        }
    play_type = random.choices(
        ["run", "pass"],
        weights=[base_weights.get("run", 0.5), base_weights.get("pass", 0.5)]
    )[0]
    if play_type == "run":
        run_style = random.choices(
            ["inside", "outside"],
            weights=[style.get("run", {}).get("inside", 0.7), style.get("run", {}).get("outside", 0.3)]
        )[0]
        formation = random.choice(["I-Form", "Singleback", "2TE"])
        return {
            "type": "run",
            "style": run_style,
            "formation": formation,
            "package": "goal_line" if formation == "2TE" else "standard"
        }
    else:
        pass_depth = random.choices(
            ["short", "medium", "deep"],
            weights=[
                style.get("pass", {}).get("short", 0.6),
                style.get("pass", {}).get("medium", 0.3),
                style.get("pass", {}).get("deep", 0.1)
            ]
        )[0]
        formation = random.choice(["3WR", "Shotgun", "Empty"])
        return {
            "type": "pass",
            "style": pass_depth,
            "formation": formation,
            "package": "spread"
        }
