from engine.core.fatigue_manager import FatigueManager

def apply_game_day_effects(team, context="post_game"):
    """
    Apply morale adjustments and trigger fatigue recovery using FatigueManager.
    """
    for player in team.get("roster", []):
        # Morale boosts/drops
        if player.get("overall", 0) > 90:
            player["confidence"] = player.get("confidence", 1.0) + 0.05
        elif player.get("overall", 0) < 60:
            player["confidence"] = player.get("confidence", 1.0) - 0.05

        # Clamp confidence between 0 and 1
        player["confidence"] = max(0.0, min(1.0, player.get("confidence", 1.0)))

    # Post-game fatigue recovery
    FatigueManager.bulk_recover(team, context)
