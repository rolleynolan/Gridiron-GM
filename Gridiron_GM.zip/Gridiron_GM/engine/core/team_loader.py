from engine.team.team import Team  # or wherever your Team class is defined
import json
import os

def load_team_by_abbr(abbr, save_name="test_league"):
    path = f"saves/{save_name}/league.json"
    if not os.path.exists(path):
        path = "mock_fictional_league.json"
    if not os.path.exists(path):
        raise FileNotFoundError(f"[TeamLoader] League file not found at {path}")

    with open(path, "r") as f:
        league_data = json.load(f)

    for team_dict in league_data["teams"]:
        if team_dict["abbreviation"] == abbr:
            team_obj = Team.from_dict(team_dict)  # <- this line is key
            return team_obj

    raise ValueError(f"Team with abbreviation {abbr} not found in {path}")
