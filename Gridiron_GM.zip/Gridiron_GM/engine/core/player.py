import random
import datetime
from engine.free_agency.free_agent_profile import FreeAgentProfile
from engine.health.injury_manager import InjuryEngine
from engine.health.injury_manager import Injury

class Player:
    def __init__(self, name, position, age, dob, college, birth_location, jersey_number, overall):
        self.name = name
        self.position = position
        self.age = age
        self.dob = dob
        self.college = college
        self.birth_location = birth_location
        self.jersey_number = jersey_number
        self.overall = overall
        self.scouted = False
        self.scouted_skills = {}
        self.scouting_progress = 0
        self.projected_overall = None
        self.projected_potential = None
        self.notes = []
        self.fatigue = 0.0
        self.contract = None
        self.experience = 0
        self.injuries = []
        self.injury_history = []
        self.weeks_out = 0
        self.retired_due_to_injury = False
        self.retired = False
        self.morale = 100
        self.playtime_history = []
        self.career_stats = {
            "passing_yards": 0,
            "rushing_yards": 0,
            "receiving_yards": 0,
            "passing_touchdowns": 0,
            "rushing_touchdowns": 0,
            "receiving_touchdowns": 0,
            "sacks": 0,
            "interceptions": 0,
            "tackles": 0
        }
        self.on_injured_reserve = False
        self.is_injured = False

        self.traits = {
            "training": [],
            "gameday": [],
            "physical": [],
            "mental": [],
            "media": []
        }
        self.skills = {}

        self.snaps = 0
        self.stamina = 80
        self.dev_tier = None
        self.sub_cooldown = 0

    def add_trait(self, category, trait):
        if category in self.traits:
            self.traits[category].append(trait)

    def get_fatigue_rate(self):
        base = 0.1
        if self.position in ["WR", "CB", "RB", "LB"]:
            base += 0.05
        base *= (100 - self.stamina) / 100
        if self.age > 30:
            base += 0.02
        if self.snaps > 10:
            base += 0.01
        return base

    def fatigue_threshold(self):
        base = 0.7
        if self.position in ["RB", "WR", "DL"]:
            base = 0.6
        elif self.position in ["QB", "OL", "K", "P"]:
            base = 0.9
        base += (self.stamina - 80) * 0.002
        return base

    def rest_snap(self):
        self.fatigue = max(0.0, self.fatigue - 0.05)
        if self.sub_cooldown > 0:
            self.sub_cooldown -= 1

    def should_sub_out(self):
        return self.fatigue >= self.fatigue_threshold() and self.sub_cooldown == 0

    def can_return(self):
        return self.fatigue <= (self.fatigue_threshold() - 0.1) and self.sub_cooldown == 0

    def mark_subbed(self):
        self.sub_cooldown = 2

    def is_fatigued(self):
        return self.fatigue >= self.fatigue_threshold()

    def play_snap(self, intensity=1.0):
        self.snaps += 1
        self.fatigue += self.get_fatigue_rate() * intensity
        self.fatigue = min(self.fatigue, 1.0)
        if self.sub_cooldown > 0:
            self.sub_cooldown -= 1

    def add_injury(self, injury):
        self.injuries.append(injury)
        self.injury_history.append(injury)
        self.weeks_out = injury.weeks_out
        self.is_injured = True

    def recover_one_week(self):
        if self.weeks_out > 0:
            self.weeks_out -= 1
            if "Quick Recovery" in self.traits.get("physical", []):
                self.weeks_out = max(1, int(self.weeks_out * 0.90))
            if self.weeks_out == 0:
                self.injuries.clear()
                self.is_injured = False

    def update_player_stats(self, stat_type, value):
        if stat_type in self.career_stats:
            self.career_stats[stat_type] += value

    def update_performance_due_to_traits(self):
        if "Clutch Performer" in self.traits["mental"]:
            self.overall += 2
        if "Lazy" in self.traits["training"]:
            self.overall -= 1

    def to_dict(self):
        return {
            "name": self.name,
            "position": self.position,
            "age": self.age,
            "dob": self.dob.isoformat() if hasattr(self.dob, 'isoformat') else self.dob,
            "college": self.college,
            "birth_location": self.birth_location,
            "jersey_number": self.jersey_number,
            "overall": self.overall,
            "fatigue": self.fatigue,
            "skills": self.skills,
            "dev_tier": self.dev_tier,
            "traits": self.traits,
            "scouted": self.scouted,
            "scouted_skills": self.scouted_skills,
            "scouting_progress": self.scouting_progress,
            "projected_overall": self.projected_overall,
            "projected_potential": self.projected_potential,
            "notes": self.notes,
            "contract": self.contract,
            "experience": self.experience,
            "injuries": [{"injury_type": inj.injury_type, "weeks_out": inj.weeks_out} for inj in self.injuries],
            "weeks_out": self.weeks_out,
            "retired_due_to_injury": self.retired_due_to_injury,
            "retired": self.retired,
            "morale": self.morale,
            "playtime_history": self.playtime_history,
            "career_stats": self.career_stats,
            "on_injured_reserve": self.on_injured_reserve,
            "is_injured": self.is_injured
        }

    @staticmethod
    def from_dict(data):
        player = Player(
            name=data["name"],
            position=data["position"],
            age=data.get("age", 22),  # default to 22 if age is missing
            dob=datetime.datetime.fromisoformat(data["dob"]) if isinstance(data["dob"], str) else data["dob"],
            college=data["college"],
            birth_location=data["birth_location"],
            jersey_number=data["jersey_number"],
            overall=data["overall"]
        )
        player.fatigue = data.get("fatigue", 0)
        player.skills = data.get("skills", {})
        player.dev_tier = data.get("dev_tier", None)
        player.traits = data.get("traits", {"training": [], "mental": [], "gameday": [], "media": []})
        player.scouted = data.get("scouted", False)
        player.scouted_skills = data.get("scouted_skills", {})
        player.scouting_progress = data.get("scouting_progress", 0)
        player.projected_overall = data.get("projected_overall", None)
        player.projected_potential = data.get("projected_potential", None)
        player.notes = data.get("notes", [])
        player.contract = data.get("contract", None)
        player.experience = data.get("experience", 0)
        player.injuries = [Injury(inj['injury_type'], inj['weeks_out'], 'Unknown', 'Unknown') for inj in data.get("injuries", [])]
        player.weeks_out = data.get("weeks_out", 0)
        player.retired_due_to_injury = data.get("retired_due_to_injury", False)
        player.retired = data.get("retired", False)
        player.morale = data.get("morale", 100)
        player.playtime_history = data.get("playtime_history", [])
        player.career_stats = data.get("career_stats", {})
        player.on_injured_reserve = data.get("on_injured_reserve", False)
        player.is_injured = data.get("is_injured", False)
        player.free_agent_profile = FreeAgentProfile(player)
        return player
