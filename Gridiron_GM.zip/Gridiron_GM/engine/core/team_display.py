def show_rosters(teams):
    for team in teams:
        print(f"\n📋 {team.city} {team.name} Roster:")
        for player in team.players:
            name = player.name if hasattr(player, "name") else player.get("name", "Unknown")
            ovr = getattr(player, "true_overall", player.get("true_overall", "??"))
            print(f" - {name} | OVR: {ovr}")

