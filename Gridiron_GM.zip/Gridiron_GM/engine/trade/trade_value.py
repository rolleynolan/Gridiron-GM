from engine.trade.draft_pick_values import PICK_VALUE_CHART
# engine/trade/trade_value.py

def evaluate_player_value(player, team):
    base_value = player.overall * 4 + player.potential * 2

    age_penalty = max(0, (player.age - 28) * 5)
    value_after_age = base_value - age_penalty

    position_multipliers = {
        "QB": 1.25, "RB": 0.9, "WR": 1.0, "TE": 0.85,
        "OL": 0.75, "DL": 0.9, "LB": 1.0, "CB": 1.1,
        "S": 1.0, "K": 0.5, "P": 0.4
    }
    pos_multiplier = position_multipliers.get(player.position, 1.0)
    value = value_after_age * pos_multiplier

    # Simulate contract penalty (e.g., reduce value if expensive)
    # Assume contract is stored as player.contract_total and contract_years
    # Here we just apply a fixed dummy penalty
    contract_penalty = 20 if hasattr(player, "contract_total") else 0
    value -= contract_penalty

    # Apply team preference multiplier if available
    if hasattr(team, "position_values"):
        team_pref = team.position_values.get(player.position, 1.0)
        value *= team_pref

    return max(1, round(value, 1))

def calculate_pick_value(pick_number, team=None, is_future=False):
    value = PICK_VALUE_CHART.get(pick_number, 1)
    if is_future:
        value *= 0.75
    return round(value, 1)
