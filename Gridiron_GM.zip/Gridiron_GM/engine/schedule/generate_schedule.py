import json
import random
import os

# Constants
PRESEASON_DAYS = ["Thursday", "Friday", "Saturday", "Sunday", "Monday"]
PRESEASON_WEEKS = range(1, 4)
BYE_BUFFER_WEEK = 4
REGULAR_SEASON_WEEKS = range(5, 23)
POSTSEASON_WEEKS = {
    23: "Wildcard",
    24: "Divisional",
    25: "Conference",
    26: "Gridiron Bowl"
}
ALL_SEASON_TYPES = {
    **{w: "Preseason" for w in PRESEASON_WEEKS},
    BYE_BUFFER_WEEK: "Bye Buffer",
    **{w: "Regular Season" for w in REGULAR_SEASON_WEEKS},
    **{w: "Playoffs" for w in POSTSEASON_WEEKS}
}

def load_custom_teams(path="config/teams.json"):
    with open(path, "r") as f:
        return [team["abbreviation"] for team in json.load(f)]

def generate_game_id(away, home, week):
    return f"{away}@{home}-W{week}"

def assign_byes(team_abbrs):
    bye_count = {
        9: 6, 10: 6, 11: 4, 12: 6, 13: 4,
        14: 4, 15: 6, 16: 4, 17: 4, 18: 2
    }
    byes = {str(week): [] for week in bye_count}
    remaining_teams = team_abbrs.copy()
    random.shuffle(remaining_teams)
    for week, count in bye_count.items():
        if not remaining_teams:
            break
        remaining_teams = list(remaining_teams)  # ← Add this before the line
        random.shuffle(remaining_teams)          # Optional for randomness

        byes[str(week)] = [remaining_teams.pop() for _ in range(min(count, len(remaining_teams)))]

    return byes

def create_weekly_matchups(team_abbrs, week, bye_teams=None, kickoff="1:00 PM", season_type="Regular Season"):
    teams_playing = [t for t in team_abbrs if not bye_teams or t not in bye_teams]
    random.shuffle(teams_playing)
    matchups = []
    for i in range(0, len(teams_playing), 2):
        if i + 1 >= len(teams_playing): break
        away, home = teams_playing[i], teams_playing[i+1]
        matchups.append((away, home))
    games = []

    if season_type == "Preseason":
        for away, home in matchups:
            games.append({
                "week": week,
                "game_id": generate_game_id(away, home, week),
                "home": home,
                "away": away,
                "day": random.choice(PRESEASON_DAYS),
                "kickoff": "12:00 PM",
                "season_type": "Preseason",
                "tags": []
            })
        return games

    # Regular season formatting
    primetime_slots = {
        "Thursday": "8:20 PM",
        "Sunday-Night": "8:20 PM",
        "Monday": "8:15 PM"
    }
    sunday_day_slots = ["1:00 PM"] * 6 + ["4:05 PM"] * 2 + ["4:25 PM"] * 2
    random.shuffle(sunday_day_slots)

    primetime_assignments = {
        "Thursday": matchups.pop() if matchups else None,
        "Sunday": matchups.pop() if matchups else None,
        "Monday": matchups.pop() if matchups else None
    }

    for slot_day, matchup in primetime_assignments.items():
        if matchup:
            away, home = matchup
            games.append({
                "week": week,
                "game_id": generate_game_id(away, home, week),
                "home": home,
                "away": away,
                "day": "Sunday" if slot_day == "Sunday" else slot_day,
                "kickoff": primetime_slots[f"{slot_day}-Night"] if slot_day == "Sunday" else primetime_slots[slot_day],
                "season_type": "Regular Season",
                "tags": ["primetime"]
            })

    for away, home in matchups:
        kickoff = sunday_day_slots.pop() if sunday_day_slots else "1:00 PM"
        games.append({
            "week": week,
            "game_id": generate_game_id(away, home, week),
            "home": home,
            "away": away,
            "day": "Sunday",
            "kickoff": kickoff,
            "season_type": "Regular Season",
            "tags": []
        })

    return games

import random

def generate_schedule(year, team_abbrs):
    schedule_by_week = {}
    bye_map = assign_byes(team_abbrs)
    total_weeks = 18
    used_matchups = set()

    for i in range(5, 5 + total_weeks):
        week_key = str(i)
        byes = bye_map.get(week_key, [])
        week_teams = [team for team in team_abbrs if team not in byes]
        random.shuffle(week_teams)
        week_games = []

        attempts = 0
        max_attempts = 100

        while len(week_teams) >= 2 and attempts < max_attempts:
            home = week_teams.pop()
            away = week_teams.pop()

            matchup_id = tuple(sorted([home, away]))
            if matchup_id in used_matchups:
                week_teams.insert(0, home)
                week_teams.insert(1, away)
                attempts += 1
                continue

            used_matchups.add(matchup_id)
            week_games.append({
                "week": i,
                "home": home,
                "away": away,
                "day": random.choice(["Sunday", "Monday", "Thursday"]),
                "kickoff": random.choice(["1:00 PM", "4:05 PM", "8:20 PM"]),
                "game_id": f"{away}@{home}-W{i}",
                "season_type": "Regular Season",
                "tags": []
            })

        schedule_by_week[week_key] = week_games

    return schedule_by_week, bye_map




def build_team_schedule(schedule_by_week, bye_map):
    team_schedules = {}
    for week_str, games in schedule_by_week.items():
        week = int(week_str)
        for game in games:
            for team_key, is_home in [(game["home"], True), (game["away"], False)]:
                opponent = game["away"] if is_home else game["home"]
                entry = {
                    "week": week,
                    "opponent": opponent,
                    "home": is_home,
                    "day": game["day"],
                    "kickoff": game["kickoff"],
                    "season_type": game.get("season_type", "Unknown")
                }
                team_schedules.setdefault(team_key, []).append(entry)

    for week_str, bye_teams in bye_map.items():
        for team in bye_teams:
            team_schedules.setdefault(team, []).append({
                "week": int(week_str),
                "opponent": None,
                "home": None,
                "day": "BYE",
                "kickoff": None,
                "season_type": "Regular Season"
            })

    for team in team_schedules:
        team_schedules[team].sort(key=lambda x: x["week"])

    return team_schedules

def save_schedule_files(schedule, bye_map, team_schedule, base_path="saves/test_league"):
    os.makedirs(base_path, exist_ok=True)
    with open(os.path.join(base_path, "schedule_by_week.json"), "w") as f:
        json.dump(schedule, f, indent=2)
    with open(os.path.join(base_path, "schedule_by_team.json"), "w") as f:
        json.dump(team_schedule, f, indent=2)

def generate_schedule_files_if_missing(save_name="test_league"):
    from engine.utils.loaders import load_teams_from_config
    from engine.schedule.generate_schedule import (
        generate_schedule,
        build_team_schedule,
        save_schedule_files
    )
    base_path = f"saves/{save_name}"
    schedule_path = os.path.join(base_path, "schedule_by_week.json")
    results_by_week = {}

    # Load existing if available
    if os.path.exists(schedule_path):
        with open(schedule_path, "r") as f:
            schedule_by_week = json.load(f)
    else:
        team_abbrs = [t["abbreviation"] for t in load_teams_from_config()]
        schedule_by_week, bye_map = generate_schedule(2025, team_abbrs)
        schedule_by_team = build_team_schedule(schedule_by_week, bye_map)
        save_schedule_files(schedule_by_week, bye_map, schedule_by_team, base_path=base_path)

    return schedule_by_week, results_by_week

# === MAIN (safe generation entry) ===
if __name__ == "__main__":
    team_abbrs = load_custom_teams()
    schedule_by_week, bye_map = generate_schedule(2025, team_abbrs)
    schedule_by_team = build_team_schedule(schedule_by_week, bye_map)
    save_schedule_files(schedule_by_week, bye_map, schedule_by_team)

    # Post-process sorting
    base_path = "saves/test_league"
    schedule_path = os.path.join(base_path, "schedule_by_week.json")

    DAY_ORDER = {"Thursday": 0, "Friday": 1, "Saturday": 2, "Sunday": 3, "Monday": 4}
    KICKOFF_ORDER = {
        "12:00 PM": 0, "1:00 PM": 1, "1:05 PM": 2, "1:25 PM": 3,
        "4:05 PM": 4, "4:25 PM": 5, "7:20 PM": 6, "8:15 PM": 7,
        "8:20 PM": 8, "8:30 PM": 9, "7:30 PM": 10
    }

    def sort_games(games):
        return sorted(
            games,
            key=lambda g: (
                DAY_ORDER.get(g.get("day"), 99),
                KICKOFF_ORDER.get(g.get("kickoff"), 99)
            )
        )

    with open(schedule_path, "r") as f:
        schedule_by_week = json.load(f)

    for week in schedule_by_week:
        schedule_by_week[week] = sort_games(schedule_by_week[week])

    with open(schedule_path, "w") as f:
        json.dump(schedule_by_week, f, indent=2)

    print("[✓] schedule_by_week.json sorted by broadcast order.")

    

