FORMATION_SCHEMES = {
    "I-FORM": {"QB": 1, "RB": 1, "FB": 1, "WR": 2, "TE": 1, "OL": 5},
    "SINGLEBACK": {"QB": 1, "RB": 1, "WR": 2, "TE": 2, "OL": 5},
    "3WR": {"QB": 1, "RB": 1, "WR": 3, "TE": 1, "OL": 5},
    "4WR": {"QB": 1, "RB": 1, "WR": 4, "TE": 0, "OL": 5},
    "2TE": {"QB": 1, "RB": 1, "WR": 2, "TE": 2, "OL": 5},
    "SHOTGUN": {"QB": 1, "RB": 1, "WR": 3, "TE": 1, "OL": 5},
    "EMPTY": {"QB": 1, "RB": 0, "WR": 5, "TE": 0, "OL": 5},
    "WILDCAT": {"QB": 0, "RB": 2, "WR": 2, "TE": 1, "OL": 5}
}