
import random
import json
import os

# Define RookiePlayer with scouting compatibility
class RookiePlayer:
    def __init__(self, name, position, college, height, weight, overall, potential, dev_tier, projected_pick):
        self.name = name
        self.position = position
        self.college = college
        self.height = height
        self.weight = weight
        self.true_overall = overall
        self.potential = potential
        self.dev_tier = dev_tier
        self.projected_pick = projected_pick
        self.experience = 0

        # Generate base attributes
        self.true_attributes = {
            "Speed": random.randint(60, 99),
            "Strength": random.randint(60, 99),
            "Awareness": random.randint(60, 99)
        }
        self.estimated_attributes = {
            k: (v - random.randint(5, 15), v + random.randint(5, 15))
            for k, v in self.true_attributes.items()
        }

        # Scouting output containers
        self.scouted_rating = {}
        self.scouted_skills = {}
        self.scout_reports = {}

    def to_dict(self):
        return {
            "name": self.name,
            "position": self.position,
            "college": self.college,
            "height": self.height,
            "weight": self.weight,
            "true_overall": self.true_overall,
            "potential": self.potential,
            "dev_tier": self.dev_tier,
            "projected_pick": self.projected_pick,
            "true_attributes": self.true_attributes,
        }

    @staticmethod
    def from_dict(data):
        player = RookiePlayer(
            name=data["name"],
            position=data["position"],
            college=data["college"],
            height=data["height"],
            weight=data["weight"],
            overall=data["true_overall"],
            potential=data["potential"],
            dev_tier=data["dev_tier"],
            projected_pick=data["projected_pick"]
        )
        player.true_attributes = data.get("true_attributes", {})
        return player



POSITIONS = [
    "QB", "RB", "WR", "TE",
    "LT", "LG", "C", "RG", "RT",
    "DE", "DT", "OLB", "MLB",
    "CB", "FS", "SS",
    "K", "P"
]


def load_colleges():
    # Resolve from the ROOT of the project instead of relative to this file
    root = os.path.abspath(os.path.join(os.path.dirname(__file__), "..", ".."))
    path = os.path.join(root, "data", "locations", "fbs_colleges.txt")
    with open(path, "r", encoding="utf-8") as f:
        return [line.strip() for line in f if line.strip()]


COLLEGES = load_colleges()


DATA_DIR = os.path.abspath(os.path.join(os.path.dirname(__file__), "..", "..", "data"))


def load_names(filename):
    path = os.path.join(DATA_DIR, "names", filename)
    with open(path, "r", encoding="utf-8") as f:
        return [line.strip() for line in f if line.strip()]

MALE_FIRST_NAMES = load_names("male_first_names.txt")
LAST_NAMES = load_names("last_names.txt")

def generate_rookie_class(num_players=150):
    rookie_class = []
    for _ in range(num_players):
        first_name = random.choice(MALE_FIRST_NAMES)
        last_name = random.choice(LAST_NAMES)
        player = RookiePlayer(
            name=f"{first_name} {last_name}",
            position=random.choice(POSITIONS),
            college=random.choice(COLLEGES),
            height=random.randint(68, 80),
            weight=random.randint(180, 330),
            overall=random.randint(50, 95),
            potential=random.randint(60, 99),
            dev_tier=random.choice(["Low", "Mid", "High", "Blue Chip"]),
            projected_pick=random.randint(1, 224)
        )
        rookie_class.append(player)
    return rookie_class

def save_rookie_class(rookie_class, filename="rookie_class.json"):
    with open(filename, "w", encoding="utf-8") as f:
        json.dump([p.to_dict() for p in rookie_class], f, indent=4)

def load_rookie_class(filename="rookie_class.json"):
    try:
        with open(filename, "r", encoding="utf-8") as f:
            data = json.load(f)
        return [RookiePlayer.from_dict(d) for d in data]
    except FileNotFoundError:
        return []
