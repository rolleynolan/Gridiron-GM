import random
from engine.core.team_loader import load_team_by_abbr

class GameSimEngine:
    def __init__(self, home_abbr, away_abbr, week, game_id=None, save_name="test_league"):
        self.week = week
        self.game_id = game_id or f"{away_abbr}@{home_abbr}-W{week}"
        self.save_name = save_name

        # Load teams
        self.home = load_team_by_abbr(home_abbr, save_name=save_name)
        self.away = load_team_by_abbr(away_abbr, save_name=save_name)

        self.home_stats = self.init_team_stats()
        self.home_stats["team"] = self.home.abbreviation

        self.away_stats = self.init_team_stats()
        self.away_stats["team"] = self.away.abbreviation


        self.result = {
        "home": self.home.abbreviation,
        "away": self.away.abbreviation,
        "home_score": 0,
        "away_score": 0,
        "log": [],
        "player_stats": {}
        }





    def init_team_stats(self):
        return {
            "total_yards": 0,
            "passing_yards": 0,
            "rushing_yards": 0,
            "turnovers": 0,
            "time_of_possession": 0  # in seconds
        }

    def simulate_drive(self, offense_stats):
        from engine.core.fatigue_manager import FatigueManager

        # Example active player pool for fatigue logic (mock names)
        # In real implementation, pull from play formation
        active_names = ["QB1", "RB1", "WR1", "WR2", "TE1", "LT", "RT", "C"]
        on_field_players = []
        for pos in active_names:
            for lst in self.home.depth_chart.values():
                for p in lst:
                    if pos.lower() in p["name"].lower():
                        on_field_players.append(p)

        for p in on_field_players:
            role = "skill" if "WR" in p["name"] or "RB" in p["name"] else "lineman"
            FatigueManager.apply_play_fatigue(p, context=role)

        yards = random.randint(10, 80)
        is_pass = random.random() < 0.65
        turnover = random.random() < 0.15
        time = random.randint(90, 240)

        if turnover:
            offense_stats["turnovers"] += 1
            yards = random.randint(0, 30)

        if is_pass:
            offense_stats["passing_yards"] += int(yards * random.uniform(0.6, 0.9))
        else:
            offense_stats["rushing_yards"] += int(yards * random.uniform(0.5, 0.8))

        offense_stats["total_yards"] += yards
        offense_stats["time_of_possession"] += time

        FatigueManager.bulk_recover(self.home, context="in_play", on_field_players=on_field_players)
        FatigueManager.bulk_recover(self.away, context="in_play", on_field_players=[])

        return yards, turnover, time
        
    def simulate(self):
        drives_per_team = random.randint(10, 14)

        home_score = 0
        away_score = 0

        for _ in range(drives_per_team):
            # Away team drive
            _, to, _ = self.simulate_drive(self.away_stats)
            if not to:
                away_score += random.choices([0, 3, 7], weights=[0.5, 0.25, 0.25])[0]

            # Home team drive
            _, to, _ = self.simulate_drive(self.home_stats)
            if not to:
                home_score += random.choices([0, 3, 7], weights=[0.5, 0.25, 0.25])[0]

        self.result["home_score"] = home_score
        self.result["away_score"] = away_score
        self.result["home_stats"] = self.format_team_stats(self.home_stats)
        self.result["away_stats"] = self.format_team_stats(self.away_stats)
        self.result["players"] = {
            self.away.abbreviation: self.fake_player_stats(self.away_stats),
            self.home.abbreviation: self.fake_player_stats(self.home_stats)
        }

        return self.result

    def format_team_stats(self, stats):
        return {
            "total_yards": stats.get("total_yards", 0),
            "passing_yards": stats.get("passing_yards", 0),
            "rushing_yards": stats.get("rushing_yards", 0),
            "turnovers": stats.get("turnovers", 0),
            "time_of_possession": stats.get("time_of_possession", 0),
            "team": stats.get("team")  # No .abbreviation — keep it as string
        }



    def fake_player_stats(self, team_stats):
        qb_yards = team_stats["passing_yards"]
        rb_yards = team_stats["rushing_yards"]
        wr_yards = int(qb_yards * random.uniform(0.6, 0.85))

        return {
            "QB": {
                "name": "QB1",
                "yards": qb_yards,
                "td": random.randint(0, 4),
                "int": random.randint(0, 2)
            },
            "RB": {
                "name": "RB1",
                "yards": rb_yards,
                "td": random.randint(0, 2)
            },
            "WR1": {
                "name": "WR1",
                "yards": wr_yards,
                "td": random.randint(0, 2)
            }
        }
