
# engine/simulation/sim_controller.py

from engine.team.rebuild_evaluation_runner import evaluate_all_teams_rebuild_mode

def simulate_week(calendar, league):
    print(f"Simulating week {calendar.current_week}...")

    # Advance the calendar
    calendar.advance_week()

    # Evaluate rebuild mode just before the trade deadline
    if calendar.is_trade_deadline_week():
        print("Trade deadline week reached. Evaluating rebuild status for all teams...")
        evaluate_all_teams_rebuild_mode(league.teams, post_playoffs=False)

    # Evaluate rebuild mode at the start of the offseason
    if calendar.is_post_playoffs_week():
        print("Offseason has begun. Re-evaluating rebuild mode for all teams...")
        evaluate_all_teams_rebuild_mode(league.teams, post_playoffs=True)

    # Additional simulation logic (games, injuries, events, etc.) would follow here
