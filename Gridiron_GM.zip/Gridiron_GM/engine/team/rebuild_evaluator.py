
# engine/team/rebuild_evaluator.py

def evaluate_rebuild_mode(team_record, roster, cap_space, draft_assets, post_playoffs=False):
    '''
    Dynamically determines whether a team should enter rebuild mode.

    Parameters:
    - team_record (tuple): (wins, losses)
    - roster (list of players): each player is a dict with 'age', 'overall', 'position'
    - cap_space (int): amount of cap space left (positive or negative)
    - draft_assets (list of picks): list of pick round numbers (e.g. [1, 2, 3, 3, 5])
    - post_playoffs (bool): True if evaluating after the playoffs

    Returns:
    - bool: True if team should enter rebuild mode
    '''

    wins, losses = team_record
    total_games = wins + losses
    win_pct = wins / total_games if total_games else 0.0

    # Skip rebuild entry right after playoffs for successful teams
    if post_playoffs and win_pct >= 0.5:
        return False

    # Check for aging roster
    average_age = sum(player['age'] for player in roster) / len(roster)
    over_30_count = sum(1 for p in roster if p['age'] >= 30)
    high_age_ratio = over_30_count / len(roster)

    # Check for lack of elite talent
    elite_player_count = sum(1 for p in roster if p['overall'] >= 88)

    # Evaluate draft capital
    has_early_picks = any(round_num <= 2 for round_num in draft_assets)

    # Rebuild triggers
    if win_pct < 0.3 and average_age > 27 and elite_player_count < 2:
        return True

    if win_pct < 0.4 and high_age_ratio > 0.4 and cap_space < 0:
        return True

    if not has_early_picks and win_pct < 0.25:
        return True

    return False
