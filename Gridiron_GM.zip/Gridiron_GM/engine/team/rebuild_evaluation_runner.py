
# engine/team/rebuild_evaluation_runner.py

def evaluate_all_teams_rebuild_mode(teams, post_playoffs=False):
    for team in teams:
        cap_space = team.get_cap_space()
        draft_assets = team.get_current_draft_picks()
        old_mode = team.rebuild_mode

        team.evaluate_rebuild_status(
            cap_space=cap_space,
            draft_assets=draft_assets,
            post_playoffs=post_playoffs
        )

        if not old_mode and team.rebuild_mode:
            print(f"{team.team_name} is now entering REBUILD MODE.")
