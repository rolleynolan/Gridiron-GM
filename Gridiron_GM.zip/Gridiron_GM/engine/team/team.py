
import os
import sys
from ..core.player import Player
from engine.team.rebuild_evaluator import evaluate_rebuild_mode


class Team:
    def __init__(self, team_name, city, abbreviation):
        self.team_name = team_name
        self.name = team_name        # ✅ This line fixes your UI code
        self.city = city
        self.abbreviation = abbreviation
        self.players = []
        self.depth_chart = {}
        self.team_record = {"wins": 0, "losses": 0, "ties": 0}
        self.playoff_seed = None
        self.rebuild_mode = False


    def add_player(self, player, position_override=None):
        """Adds a player to the team's roster and optionally slots into the depth chart."""
        self.players.append(player)
        position = position_override or player.position

        if position not in self.depth_chart:
            self.depth_chart[position] = []

        self.depth_chart[position].append(player)

    def remove_player(self, player):
        """Removes a player from the roster and depth chart."""
        if player in self.players:
            self.players.remove(player)

        for position, player_list in self.depth_chart.items():
            if player in player_list:
                player_list.remove(player)

    def generate_depth_chart(self):
        """Auto-builds a basic depth chart by grouping players by position."""
        self.depth_chart = {}
        for player in self.players:
            position = player.position
            if position not in self.depth_chart:
                self.depth_chart[position] = []
            self.depth_chart[position].append(player)

    def evaluate_rebuild_status(self, cap_space, draft_assets, post_playoffs=False):
        """Evaluates whether the team should enter rebuild mode."""
        self.rebuild_mode = evaluate_rebuild_mode(
            team_record=(self.team_record["wins"], self.team_record["losses"]),
            roster=[player.to_dict() for player in self.players],
            cap_space=cap_space,
            draft_assets=draft_assets,
            post_playoffs=post_playoffs
        )

    def to_dict(self):
        return {
            "team_name": self.team_name,
            "city": self.city,
            "abbreviation": self.abbreviation,
            "players": [player.to_dict() for player in self.players],
            "depth_chart": {pos: [p.name for p in players] for pos, players in self.depth_chart.items()},
            "team_record": self.team_record,
            "playoff_seed": self.playoff_seed,
            "rebuild_mode": self.rebuild_mode
        }



    @classmethod
    def from_dict(cls, data):
        team = cls(
            team_name=data.get("team_name", "Unnamed Team"),
            city=data.get("city", "Unknown City"),
            abbreviation=data.get("abbreviation", "UNK")
        )
        team.players = [Player.from_dict(p) for p in data.get("players", [])]
        team.generate_depth_chart()
        team.team_record = data.get("team_record", {"wins": 0, "losses": 0, "ties": 0})
        team.playoff_seed = data.get("playoff_seed", None)
        team.rebuild_mode = data.get("rebuild_mode", False)
        return team



    def __repr__(self):
        return f"{self.team_name} | Roster Size: {len(self.players)}"
