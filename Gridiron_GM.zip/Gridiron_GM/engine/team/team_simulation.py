
import random

# Basic city list for now
SIM_CITIES = [
    "New York", "Los Angeles", "Chicago", "Houston", "Phoenix",
    "Philadelphia", "San Antonio", "San Diego", "Dallas", "San Jose"
]

class Team:
    def __init__(self, name, city, players):
        self.name = name
        self.city = city
        self.players = players
        self.record = {"W": 0, "L": 0, "T": 0}

    def display(self):
        return f"{self.city} {self.name}"

def convert_rosters_to_teams(team_rosters):
    """
    Convert team rosters from draft into sim-ready Team objects.
    """
    sim_teams = []
    used_cities = set()

    for team_name, roster in team_rosters.items():
        # Pick a unique city
        city = random.choice([c for c in SIM_CITIES if c not in used_cities] or ["Metro"])
        used_cities.add(city)

        sim_team = Team(name=team_name, city=city, players=roster.players)
        sim_teams.append(sim_team)

    return sim_teams
