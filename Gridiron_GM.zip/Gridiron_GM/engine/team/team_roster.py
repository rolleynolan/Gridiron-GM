from engine.core.player import Player
from datetime import datetime
import random

class TeamRoster:
    def __init__(self, name):
        self.name = name
        self.players = []

    def add_player(self, player, round_number=None):
        player.round_number = round_number  # Optionally store round for UI/stats
        self.players.append(player)

    def to_dict(self):
        return {
            "team": self.name,
            "players": [p.__dict__ for p in self.players]  # optional: for saving
        }


def build_rosters_from_draft(draft_board):
    team_rosters = {}
    for team, players in draft_board.items():
        roster = TeamRoster(team)
        for i, player in enumerate(players):
            if not isinstance(player, Player):
                print(f"[ZOMBIE FIX] Converting dict to Player in {team} roster at index {i}: {player}")
                player = Player(
                    name=player.get("name", "Unknown"),
                    position=player.get("position", "?"),
                    age=22,
                    dob=datetime.now(),
                    school=player.get("college", "Unknown U"),
                    birth_location="Unknown",
                    jersey_number=random.randint(1, 99),
                    overall=player.get("overall", 70)
                )
            roster.add_player(player, round_number=(i // 1) + 1)
        team_rosters[team] = roster
    return team_rosters
