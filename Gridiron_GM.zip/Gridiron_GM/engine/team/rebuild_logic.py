
class RebuildAnalyzer:
    def __init__(self, team_data):
        self.team_data = team_data

    def evaluate(self):
        score = 0
        if self.team_data.get("age_avg", 0) > 29:
            score += 1
        if self.team_data.get("record", [0, 0])[0] < 5:
            score += 1
        if self.team_data.get("cap_space", 0) > 20_000_000:
            score -= 1
        return "Rebuild" if score >= 2 else "Contend"
