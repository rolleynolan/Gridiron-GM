import os
import json

def generate_playoff_bracket(standings_by_conference, year, save_name="test_league"):
    bracket = {}

    for conference in ["Nova", "Atlas"]:
        conference_standings = standings_by_conference.get(conference, [])

        # Defensive check to ensure we have enough teams
        if len(conference_standings) < 7:
            raise ValueError(f"Not enough teams in {conference} conference to generate playoff bracket.")

        # Sort teams by seed (assumed pre-sorted by standings manager)
        top_seven = conference_standings[:7]

        # Assign seeds 1–7
        seeds = [{"team": team, "seed": i + 1} for i, team in enumerate(top_seven)]

        # Wild Card Round matchups (seed 1 gets a bye)
        wildcard = [
            {"home": seeds[1]["team"], "away": seeds[6]["team"], "round": "Wild Card"},
            {"home": seeds[2]["team"], "away": seeds[5]["team"], "round": "Wild Card"},
            {"home": seeds[3]["team"], "away": seeds[4]["team"], "round": "Wild Card"},
        ]

        bracket[conference] = {
            "seeds": seeds,
            "wildcard": wildcard,
            "divisional": [],
            "conference": []
        }

    # Gridiron Bowl is a neutral site game between conference champions
    bracket["gridiron_bowl"] = None

    os.makedirs(f"saves/{save_name}/playoffs", exist_ok=True)
    path = f"saves/{save_name}/playoffs/playoff_bracket_{year}.json"
    with open(path, "w") as f:
        json.dump(bracket, f, indent=2)

    print(f"[PLAYOFFS] Bracket for {year} generated and saved.")
    return bracket


def maybe_generate_playoffs(week, year, standings_manager, save_name="test_league"):
    bracket_path = f"saves/{save_name}/playoffs/playoff_bracket_{year}.json"
    if os.path.exists(bracket_path):
        print("[SIM] Playoffs triggered. Halting sim to prevent duplicate generation.")
        return

    standings_by_conf = standings_manager.get_sorted_standings_by_conference()
    return generate_playoff_bracket(standings_by_conf, year, save_name=save_name)
