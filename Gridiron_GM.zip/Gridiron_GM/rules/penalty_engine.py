
from dataclasses import dataclass
import random
from typing import List

@dataclass
class Player:
    name: str
    position: str
    discipline_rating: int  # 0–100 scale
    traits: List[str]  # e.g., ["Hot-Headed", "Disciplined"]

# Penalty types and base frequencies
PENALTIES = {
    "False Start": {"base_chance": 0.03, "positions": ["OL", "TE"]},
    "Holding": {"base_chance": 0.02, "positions": ["OL"]},
    "Pass Interference": {"base_chance": 0.015, "positions": ["CB", "S"]},
    "Offside": {"base_chance": 0.01, "positions": ["DL", "LB"]},
}

# Coach modifier added
def simulate_penalty(player: Player, discipline_modifier: float = 0.0) -> str | None:
    for penalty, data in PENALTIES.items():
        if player.position not in data["positions"]:
            continue

        base_chance = data["base_chance"]
        trait_modifier = -0.01 if "Disciplined" in player.traits else 0.01 if "Hot-Headed" in player.traits else 0
        discipline_penalty = (50 - player.discipline_rating) / 500  # scaled discipline impact

        final_chance = base_chance + trait_modifier + discipline_penalty + discipline_modifier

        if random.random() < final_chance:
            return penalty
    return None

# Coach modifier passed down
def simulate_play(players: List[Player], discipline_modifier: float = 0.0) -> List[str]:
    results = []
    for player in players:
        penalty = simulate_penalty(player, discipline_modifier)
        if penalty:
            results.append(f"{player.name} ({player.position}) committed a {penalty}")
    return results

@dataclass
class DriveState:
    down: int = 1
    yards_to_go: int = 10
    yard_line: int = 25  # Start at own 25
    result: str = "In Progress"

def simulate_drive(players: List[Player], discipline_modifier: float = 0.0, max_plays: int = 8) -> dict:
    state = DriveState()
    penalty_log = []

    for play_num in range(1, max_plays + 1):
        penalties = simulate_play(players, discipline_modifier)
        for penalty in penalties:
            penalty_log.append(f"Play {play_num}: {penalty}")
            state.yard_line = max(1, state.yard_line - 10)
            state.down = min(4, state.down + 1)
            state.yards_to_go += 10

        gain = random.randint(5, 15)
        state.yard_line += gain
        state.yards_to_go -= gain

        if state.yards_to_go <= 0:
            state.down = 1
            state.yards_to_go = 10
        else:
            state.down += 1

        if state.down > 4:
            state.result = "Punt"
            break

        if state.yard_line >= 100:
            state.result = "Touchdown"
            break

    if state.result == "In Progress":
        state.result = "Field Goal Attempt" if state.yard_line >= 70 else "Punt"

    return {
        "Result": state.result,
        "Final Yard Line": state.yard_line,
        "Penalties": penalty_log
    }
