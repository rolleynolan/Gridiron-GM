import json
from engine.roster.roster_generator import RosterGenerator
from engine.core.college_player_generator import (
    generate_initial_college_db,
    generate_draft_class
)
from engine.team.team_simulation import convert_rosters_to_teams
from engine.scouting.scout import Scout
from engine.team.team import Team
from engine.core.calendar import Calendar

def create_game_world():
    with open("config/teams.json", "r", encoding="utf-8") as f:
        team_defs = json.load(f)

    sim_teams = []
    for t in team_defs:
        team = Team(team_name=t["name"], city=t["city"], abbreviation=t["abbreviation"])
        sim_teams.append(team)

    # ✅ Build and assign realistic rosters
    builder = RosterGenerator()
    for team in sim_teams:
        roster = builder.generate_team_roster()
        for player in roster:
            team.add_player(player)

    # ✅ Generate rookie draft class
    college_db = generate_initial_college_db(num_per_class=2825)
    draft_pool = generate_draft_class(college_db)

    calendar = Calendar()

    return {
        "teams": sim_teams,
        "all_teams": sim_teams[:],
        "draft_pool": draft_pool,
        "calendar": calendar,
        "playoff_round": 0
    }
