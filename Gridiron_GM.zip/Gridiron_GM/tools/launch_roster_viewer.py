from tkinter import Tk
from gui.roster_screen import RosterScreen

# === MOCK GAME WORLD ===
mock_game_world = {
    "all_teams": [
        {
            "city": "Chicago", "name": "Cyclones",
            "roster": [
                {
                    "name": "J. Fields", "position": "QB", "overall": 78, "potential": 88, "age": 24,
                    "fatigue": 10, "morale": 80, "traits": ["Dual Threat", "Team Leader"], "injured": False,
                    "contract": {"salary": 5, "years": 2}
                },
                {
                    "name": "D. Mooney", "position": "WR", "overall": 83, "potential": 85, "age": 27,
                    "fatigue": 5, "morale": 72, "traits": ["Deep Threat"], "injured": True,
                    "contract": {"salary": 4, "years": 1}
                },
                {
                    "name": "R. Johnson", "position": "CB", "overall": 79, "potential": 90, "age": 25,
                    "fatigue": 8, "morale": 76, "traits": ["Shutdown"], "injured": False,
                    "contract": {"salary": 6, "years": 3}
                }
            ]
        },
        {
            "city": "Orlando", "name": "Thunderbirds",
            "roster": [
                {
                    "name": "M. Griffin", "position": "RB", "overall": 82, "potential": 86, "age": 26,
                    "fatigue": 12, "morale": 70, "traits": ["Power Back"], "injured": False,
                    "contract": {"salary": 7, "years": 1}
                },
                {
                    "name": "C. Jones", "position": "MLB", "overall": 77, "potential": 81, "age": 28,
                    "fatigue": 6, "morale": 68, "traits": ["Tackling Machine"], "injured": True,
                    "contract": {"salary": 4, "years": 2}
                }
            ]
        }
    ]
}

# === UI Launch ===
if __name__ == "__main__":
    root = Tk()
    root.title("Gridiron GM - Roster Viewer")
    root.geometry("1100x600")

    app = RosterScreen(root, mock_game_world)
    root.mainloop()
