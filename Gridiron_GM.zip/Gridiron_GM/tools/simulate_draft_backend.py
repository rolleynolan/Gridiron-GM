
import random

def simulate_draft(draft_pool, teams, scouts_by_team):
    """
    Simulate a draft where each team picks the best scouted player available.
    Args:
        draft_pool (list): List of rookie Player objects.
        teams (list): Team names in draft order.
        scouts_by_team (dict): Maps team name to its assigned Scout object.
    Returns:
        dict: team_name -> list of drafted players
    """
    draft_board = {team: [] for team in teams}
    available_players = draft_pool.copy()

    for round_num in range(1, 8):  # 7 rounds
        print(f"\n==== Round {round_num} ====")
        for team in teams:
            scout = scouts_by_team.get(team)

            # Evaluate all available players from this team's scout's perspective
            scored_players = []
            for player in available_players:
                if team not in player.scouted_rating:
                    scout.evaluate_player(player, team)
                scored_players.append((player, player.scouted_rating[team]))

            # Pick the best-rated available player
            scored_players.sort(key=lambda x: x[1], reverse=True)
            if not scored_players:
                continue
            selected, rating = scored_players[0]
            draft_board[team].append(selected)
            available_players.remove(selected)
            print(f"{team} selects {selected.name} ({selected.position}) - {rating}/100")

    return draft_board
