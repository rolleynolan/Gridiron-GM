from tkinter import Tk
from gui.schedule_screen import ScheduleScreen

mock_schedule = {
    "1": [
        {"day": "Sunday", "date": "2025-09-07", "time": "1:00 PM",
         "home": "Chicago Cyclones", "away": "Phoenix Fire", "home_score": 24, "away_score": 27},
        {"day": "Sunday", "date": "2025-09-07", "time": "4:25 PM",
         "home": "New York Empire", "away": "Orlando Thunderbirds", "home_score": 21, "away_score": 20},
    ],
    "2": [
        {"day": "Thursday", "date": "2025-09-11", "time": "8:20 PM",
         "home": "Phoenix Fire", "away": "Orlando Thunderbirds", "home_score": None, "away_score": None},
        {"day": "Sunday", "date": "2025-09-14", "time": "1:00 PM",
         "home": "Chicago Cyclones", "away": "New York Empire", "home_score": None, "away_score": None},
    ]
}

mock_team_records = {
    "Chicago Cyclones": (1, 0),
    "Phoenix Fire": (0, 1),
    "New York Empire": (1, 0),
    "Orlando Thunderbirds": (0, 1),
}

if __name__ == "__main__":
    root = Tk()
    root.title("Gridiron GM - Schedule & Results")
    root.geometry("850x500")

    app = ScheduleScreen(root, mock_schedule, mock_team_records)
    root.mainloop()
