import tkinter as tk
from tkinter import ttk
from gui.player_detail_modal import PlayerDetailModal
from gui.game_results_viewer import GameResultsViewer
from engine.core.player import Player
import random
import sys, os
from datetime import datetime

CURRENT_DIR = os.path.dirname(os.path.abspath(__file__))
PROJECT_ROOT = os.path.abspath(os.path.join(CURRENT_DIR, "..", ".."))
if PROJECT_ROOT not in sys.path:
    sys.path.insert(0, PROJECT_ROOT)

from engine.core.save_system import SaveSystem


class GridironGMApp:
    def __init__(self, master, game_world, simulate_week_fn, view_rosters_fn, run_draft_fn):
        self.master = master
        self.game_world = game_world
        self.simulate_week = simulate_week_fn
        self.view_rosters = view_rosters_fn
        self.run_draft = run_draft_fn

        master.title("Gridiron GM - Control Panel")

        self.label = tk.Label(master, text="Gridiron GM Franchise Simulator", font=("Helvetica", 16))
        self.label.pack(pady=10)

        calendar = self.game_world["calendar"]
        calendar_info = calendar.get_display_info()
        self.status_var = tk.StringVar()
        self.status_var.set(f"{calendar_info['Label']} | {calendar_info['Day of Week']}, {calendar_info['Date']}")

        self.status_label = tk.Label(master, textvariable=self.status_var, font=("Helvetica", 12))
        self.status_label.pack(pady=5)

        self.advance_button = tk.Button(master, text="Advance Week", command=self.advance_week)
        self.advance_button.pack(pady=5)

        self.roster_button = tk.Button(master, text="View Rosters", command=self.view_rosters)
        self.roster_button.pack(pady=5)

        self.results_button = tk.Button(master, text="View Scores", command=self.view_scores)
        self.results_button.pack(pady=5)

        self.save_button = tk.Button(master, text="Save Game", command=self.save_game)
        self.save_button.pack(pady=5)

        self.load_button = tk.Button(master, text="Load Game", command=self.load_game)
        self.load_button.pack(pady=5)

        self.draft_button = tk.Button(master, text="Run Draft", command=self.run_draft)
        self.draft_button.pack(pady=5)

        self.quit_button = tk.Button(master, text="Quit", command=master.quit)
        self.quit_button.pack(pady=10)

    def advance_week(self):
        self.simulate_week(self.game_world)
        calendar = self.game_world['calendar']
        calendar_info = calendar.get_display_info()
        self.status_var.set(f"{calendar_info['Label']} | {calendar_info['Day of Week']}, {calendar_info['Date']}")

    def save_game(self):
        SaveSystem(self.game_world)

    def load_game(self):
        self.game_world = SaveSystem()
        calendar = self.game_world["calendar"]
        calendar_info = calendar.get_display_info()
        self.status_var.set(f"{calendar_info['Label']} | {calendar_info['Day of Week']}, {calendar_info['Date']}")

    def view_scores(self):
        GameResultsViewer(self.master, self.game_world)


class TeamRosterViewer:
    def __init__(self, root, game_world):
        self.root = root
        self.game_world = game_world

        self.label = tk.Label(root, text="Select a Team to View Roster", font=("Helvetica", 14))
        self.label.pack(pady=10)

        self.team_selector = ttk.Combobox(root, values=[f"{t.city} {t.name}" for t in game_world["all_teams"]])
        self.team_selector.pack(pady=5)
        self.team_selector.bind("<<ComboboxSelected>>", self.display_roster)

        self.roster_list = tk.Listbox(root, width=50)
        self.roster_list.pack(pady=10)
        self.roster_list.bind("<Double-Button-1>", self.open_player_modal)

    def display_roster(self, event):
        selected = self.team_selector.get()
        team = next((t for t in self.game_world["all_teams"] if f"{t.city} {t.name}" == selected), None)
        self.roster_list.delete(0, tk.END)

        if team:
            for player in team.players:
                if player is None:
                    continue
                name = getattr(player, "name", "Unknown")
                pos = getattr(player, "position", "?")
                ovr = getattr(player, "overall", "?")
                self.roster_list.insert(tk.END, f"{name} - {pos} ({ovr})")

    def open_player_modal(self, event):
        try:
            index = self.roster_list.curselection()[0]
            list_text = self.roster_list.get(index)
            player_name = list_text.split(" - ")[0]

            selected_team = self.team_selector.get()
            team = next((t for t in self.game_world["all_teams"] if f"{t.city} {t.name}" == selected_team), None)
            player = next((p for p in team.players if getattr(p, 'name', None) == player_name), None)

            if player:
                data = self.build_player_data(player)
                PlayerDetailModal(self.root, data)

        except IndexError:
            pass

    def build_player_data(self, player):
        get = lambda x, default='?': getattr(player, x, default)
        return {
            'name': get('name'),
            'position': get('position'),
            'dob': get('dob', 'Unknown'),
            'age': get('age', 22),
            'school': get('school', 'Unknown U'),
            'draft_info': get('draft_info', 'Undrafted'),
            'dev_curve': get('dev_curve', 'Unknown'),
            'attributes': getattr(player, 'attributes', {
                'Speed': get('speed', 70),
                'Awareness': get('awareness', 65)
            }),
            'traits': getattr(player, 'traits', ['None Found']),
            'career_stats': getattr(player, 'career_stats', {})
        }


if __name__ == "__main__":
    from engine.core.game_simulator import simulate_week
    from engine.core.team_display import show_rosters
    from tools.simulate_draft_backend import simulate_draft
    from engine.scouting.scout import Scout
    from tools.build_game_world import create_game_world

    def ui_simulate_week(game_world):
        simulate_week(game_world)

    def ui_view_rosters():
        roster_window = tk.Toplevel()
        roster_window.title("Team Rosters")
        TeamRosterViewer(roster_window, game_world)

    def ui_run_draft():
        calendar = game_world["calendar"]
        if not calendar.is_draft_window():
            print("[DRAFT BLOCKED] Not within valid draft window.")
            return
        if getattr(calendar, "draft_completed", False):
            print("[DRAFT BLOCKED] Draft already completed this year.")
            return

        teams = [t.name for t in game_world["all_teams"]]
        scouts = {name: Scout(name=f"{name} Scout", role="College") for name in teams}
        draft_board = simulate_draft(game_world["draft_pool"], teams, scouts)
        print("[DRAFT COMPLETE] Drafted players:", list(draft_board.keys())[:5])

        all_picks = []
        for team_name, players in draft_board.items():
            for player in players:
                all_picks.append((team_name, player))

        for global_pick, (team_name, player) in enumerate(all_picks):
            round_num = (global_pick // 32) + 1
            pick_in_round = (global_pick % 32) + 1

            team_obj = next((t for t in game_world["all_teams"] if t.name == team_name), None)
            if not team_obj:
                continue

            if not hasattr(player, 'school'):
                player.school = getattr(player, 'college', 'Unknown U')

            player.draft_info = f"{calendar.current_year}, Round {round_num}, Pick {pick_in_round}"
            print(f"[DRAFTED] {player.name} | School: {player.school} | {player.draft_info}")

            if isinstance(player, dict):
                player = Player(
                    name=player.get("name", "Unknown"),
                    position=player.get("position", "?"),
                    age=22,
                    dob=datetime.now(),
                    school=player.get("college", "Unknown U"),
                    birth_location="Unknown",
                    jersey_number=random.randint(1, 99),
                    overall=player.get("overall", 70)
                )

            team_obj.players.append(player)

        calendar.draft_completed = True

    game_world = create_game_world()
    for team in game_world["all_teams"]:
        for i, player in enumerate(team.players):
            if not isinstance(player, Player):
                print(f"[ZOMBIE] {team.city} {team.name} player #{i}: {type(player)} — {player}")
            elif not getattr(player, "name", None):
                print(f"[HEADLESS] {team.city} {team.name} player #{i} has no name — object: {player}")

    root = tk.Tk()
    app = GridironGMApp(root, game_world, ui_simulate_week, ui_view_rosters, ui_run_draft)
    root.mainloop()
