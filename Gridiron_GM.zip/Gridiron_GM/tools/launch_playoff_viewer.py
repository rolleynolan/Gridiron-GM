from tkinter import Tk
from gui.playoff_screen import PlayoffScreen

mock_bracket = {
    "Nova": [
        {"seed": 1, "team": "Phoenix Fire", "opponent": None, "score": None},
        {"seed": 2, "team": "Chicago Cyclones", "opponent": {"seed": 7, "team": "San Diego Surge"}, "score": "31-17"},
        {"seed": 3, "team": "Detroit Outlaws", "opponent": {"seed": 6, "team": "Seattle Eclipse"}, "score": "24-21"},
        {"seed": 4, "team": "St. Louis Stingers", "opponent": {"seed": 5, "team": "Boston Battalion"}, "score": "28-27"},
    ],
    "Atlas": [
        {"seed": 1, "team": "New York Empire", "opponent": None, "score": None},
        {"seed": 2, "team": "Orlando Thunderbirds", "opponent": {"seed": 7, "team": "Nashville Storm"}, "score": "30-20"},
        {"seed": 3, "team": "Atlanta Aviators", "opponent": {"seed": 6, "team": "Houston Vipers"}, "score": "27-24"},
        {"seed": 4, "team": "Denver Bighorns", "opponent": {"seed": 5, "team": "Dallas Desperados"}, "score": "34-33"},
    ]
}

if __name__ == "__main__":
    root = Tk()
    root.title("Gridiron GM - Playoff Bracket")
    root.geometry("700x600")

    app = PlayoffScreen(root, mock_bracket)
    root.mainloop()
