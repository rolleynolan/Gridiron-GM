from tkinter import Tk
from gui.standings_screen import StandingsScreen
from engine.core.standings_manager import StandingsManager
from tools.game_save_load import load_game_world

def convert_standings_for_ui(standings_manager, teams):
    grouped = {"Nova": [], "Atlas": []}
    for team in teams:
        record = standings_manager.get_team_record(team["abbreviation"])
        grouped[team["conference"]].append({
            "city": team["city"],
            "name": team["name"],
            "wins": record["wins"],
            "losses": record["losses"],
            "ties": record["ties"],
            "points_for": record.get("points_for", 0),
            "points_against": record.get("points_against", 0)
        })
    return grouped

if __name__ == "__main__":
    root = Tk()
    root.title("Gridiron GM - League Standings")
    root.geometry("700x600")

    game_world = load_game_world()
    standings_manager = StandingsManager(game_world)
    standings_data = convert_standings_for_ui(standings_manager, game_world["all_teams"])

    app = StandingsScreen(root, standings_data)
    root.mainloop()
