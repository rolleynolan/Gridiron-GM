from engine.core.calendar import Calendar
from engine.core.season_manager import SeasonManager
from engine.utils.loaders import load_teams_from_config
import json
import os

# Load teams and initialize calendar
league = load_teams_from_config()
calendar = Calendar()

# Simulate full season
season = SeasonManager(calendar, league, save_name="test_league")
season.sim_to_week(22)

# Check if playoff bracket was generated
bracket_path = "saves/test_league/playoffs/playoff_bracket_2025.json"
if os.path.exists(bracket_path):
    with open(bracket_path) as f:
        bracket = json.load(f)
        print("[SUCCESS] Playoff bracket generated:")
        print(json.dumps(bracket, indent=2))
else:
    print("[ERROR] Playoff bracket file not found. Was the season fully simulated?")
