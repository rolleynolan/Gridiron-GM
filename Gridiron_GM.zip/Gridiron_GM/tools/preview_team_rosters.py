
import sys
import os

# Set up pathing
CURRENT_DIR = os.path.dirname(os.path.abspath(__file__))
PROJECT_ROOT = os.path.abspath(os.path.join(CURRENT_DIR, "..", ".."))
sys.path.append(PROJECT_ROOT)

from tools.simulate_draft_backend import simulate_draft
from engine.core.college_player_generator import generate_college_player
from engine.scouting.scout import Scout
from engine.team.team_roster import build_rosters_from_draft

# === Generate Draft Class ===
draft_pool = [generate_college_player(year_in_college=3) for _ in range(64)]

# === Create Teams + Scouts ===
teams = ["Packers", "Bears", "Cowboys", "Dolphins", "Falcons", "Raiders", "Seahawks", "Giants"]
scouts_by_team = {
    team: Scout(name=f"{team} Scout", role="College") for team in teams
}

# === Run Draft ===
draft_board = simulate_draft(draft_pool, teams, scouts_by_team)

# === Build Rosters ===
team_rosters = build_rosters_from_draft(draft_board)

# === Preview Output ===
print("\n==== TEAM ROSTER PREVIEW ====")
for team, roster in team_rosters.items():
    print(f"\n{team} Roster:")
    for player in roster.players[:3]:  # Show top 3 picks
        print(f"  - {player['name']} ({player['position']}) from {player['college']}, OVR {player['overall']}")
