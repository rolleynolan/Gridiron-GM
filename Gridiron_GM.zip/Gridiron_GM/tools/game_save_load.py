import json
import os
from datetime import datetime
from engine.core.player import Player

def save_game_world(game_world, file_path="savegame.json"):
    """Serialize and save the game_world to disk."""
    safe_world = {
        "calendar": game_world["calendar"],
        "playoff_round": game_world.get("playoff_round", 0),
        "teams": [team_to_dict(t) for t in game_world["teams"]],
        "all_teams": [team_to_dict(t) for t in game_world["all_teams"]],
        "draft_pool": [p.to_dict() if hasattr(p, "to_dict") else p for p in game_world.get("draft_pool", [])]
    }
    with open(file_path, "w", encoding="utf-8") as f:
        json.dump(safe_world, f, indent=2)
    print(f"[SAVE] Game saved to {file_path}")

def load_game_world(file_path="savegame.json"):
    """Load and reconstruct game_world from disk."""
    if not os.path.exists(file_path):
        raise FileNotFoundError(f"Save file {file_path} not found.")

    with open(file_path, "r", encoding="utf-8") as f:
        data = json.load(f)

    game_world = {
        "calendar": data["calendar"],
        "playoff_round": data.get("playoff_round", 0),
        "teams": [dict_to_team(td) for td in data["teams"]],
        "all_teams": [dict_to_team(td) for td in data["all_teams"]],
        "draft_pool": [safe_player_from_dict(p) for p in data.get("draft_pool", [])]
    }
    print(f"[LOAD] Game loaded from {file_path}")
    return game_world

# Helpers for teams with embedded players

def team_to_dict(team):
    return {
        "name": team.name,
        "city": team.city,
        "record": team.record,
        "players": [p.to_dict() if hasattr(p, "to_dict") else p for p in team.players]
    }

def dict_to_team(data):
    class Team:
        pass

    team = Team()
    team.name = data["name"]
    team.city = data["city"]
    team.record = data.get("record", {"W": 0, "L": 0, "T": 0})
    team.players = [safe_player_from_dict(p) for p in data.get("players", [])]
    return team

def safe_player_from_dict(data):
    """Wrapper to safely convert a dict to a Player object with fallbacks."""
    try:
        dob_raw = data.get("dob", "2000-01-01")
        dob = datetime.fromisoformat(dob_raw) if isinstance(dob_raw, str) else dob_raw
        return Player(
            name=data.get("name", "Unknown"),
            position=data.get("position", "WR"),
            age=data.get("age", 22),
            dob=dob,
            college=data.get("college", "Unknown"),
            birth_location=data.get("birth_location", "Unknown"),
            jersey_number=data.get("jersey_number", 0),
            overall=data.get("overall", 50)
        )
    except Exception as e:
        print(f"[WARNING] Could not create player from data: {e}")
        return None
