from engine.core.calendar import Calendar
from engine.core.season_manager import SeasonManager
import json
import os
from datetime import date

# Load the fictional league file
with open("mock_fictional_league.json") as f:
    league = json.load(f)

# Create calendar and set save name
calendar = Calendar()
save_name = "test_league"

# Load schedule/results context
with open(f"saves/{save_name}/schedule_by_week.json") as f:
    schedule = json.load(f)

try:
    with open(f"saves/{save_name}/history/season_{calendar.current_year}_results.json") as f:
        results = json.load(f)
except FileNotFoundError:
    results = {}

calendar.set_schedule_context(schedule, results)
season = SeasonManager(calendar, league, save_name)

# Simulate full regular season
print(f"\n=== [TEST] Simulating full season for {calendar.current_year} ===")
while calendar.current_week <= 22:
    season.advance_day()

# Bracket should be generated now
bracket_path = f"saves/{save_name}/playoffs/playoff_bracket_{calendar.current_year}.json"
if os.path.exists(bracket_path):
    print(f"[PASS] Playoff bracket generated: {bracket_path}")
    with open(bracket_path, "r") as f:
        bracket = json.load(f)
    print(json.dumps(bracket, indent=2))
else:
    print("[FAIL] Playoff bracket was not generated.")

# Simulate one week into playoffs (Wildcard round)
print("\n=== [TEST] Simulating Wildcard Round ===")
for _ in range(7):  # Simulate Tuesday to Monday
    season.advance_day()

results_path = f"saves/{save_name}/results_{calendar.current_date.year}.json"
if os.path.exists(results_path):
    with open(results_path) as f:
        all_results = json.load(f)
    if "23" in all_results:
        print("[PASS] Wildcard games simulated.")
        for game in all_results["23"]:
            if game.get("round") == "Wildcard":
                print(f"{game['away']} @ {game['home']} = {game['away_score']} - {game['home_score']}")

    else:
        print("[FAIL] No Wildcard games found in results.")
else:
    print("[FAIL] Results file not found.")
