
import json
import os

class ConfigLoader:
    def __init__(self, json_path="config/settings.json", fallback_module=None):
        self.json_path = json_path
        self.fallback_module = fallback_module
        self.config = self.load_config()

    def load_config(self):
        config = {}
        if os.path.exists(self.json_path):
            with open(self.json_path) as f:
                config.update(json.load(f))
        if self.fallback_module:
            for attr in dir(self.fallback_module):
                if attr.isupper():
                    config.setdefault(attr, getattr(self.fallback_module, attr))
        return config
