
from engine.core.league_manager import LeagueManager
from engine.core.player import Player
from engine.team.team import Team

# Create league and a few teams
league = LeagueManager()

# Create a team with aging players and a bad record to trigger rebuild mode
aging_team = Team("Old Lions")
for _ in range(53):
    player = Player(
    name="Vet",
    age=32,
    position="QB",
    overall=72,
    potential=75,
    dob="1992-01-01",
    college="Old State",
    birth_location="Nowhere, USA",
    jersey_number=12
)

    aging_team.add_player(player)

league.add_team(aging_team)

# Set team record to a losing one to help trigger rebuild logic
league.standings["Old Lions"] = {"wins": 1, "losses": 6, "ties": 0}
aging_team.team_record = league.standings["Old Lions"]

# Simulate through to trade deadline week (Week 8)
while league.calendar.current_week < 8:
    league.advance_week()

# Output rebuild status
print(f"\nRebuild Mode for {aging_team.team_name}: {aging_team.rebuild_mode}")
