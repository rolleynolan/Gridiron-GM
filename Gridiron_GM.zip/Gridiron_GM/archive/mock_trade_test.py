
# tools/mock_trade_test.py

from engine.trade.trade_value import calculate_player_value_debug, calculate_pick_value
from engine.trade.trade_decision import should_cpu_accept_trade
from engine.trade.draft_pick_values import PICK_VALUE_CHART

# Mock team preferences
team_A_prefs = {
    "QB": 1.25,
    "WR": 1.1,
    "values_1st": 1.1,
    "values_late": 0.9,
    "rebuild_mode": False
}

team_B_prefs = {
    "QB": 1.0,
    "WR": 0.95,
    "values_1st": 1.2,
    "values_late": 1.2,
    "rebuild_mode": True
}

# Team context for decision function
team_A_context = {
    "rebuild_mode": False,
    "is_contender": True,
    "over_the_cap": False
}

team_B_context = {
    "rebuild_mode": True,
    "is_contender": False,
    "over_the_cap": False
}

# Mock players
player_1 = {
    "name": "Veteran QB",
    "overall": 84,
    "potential": 86,
    "age": 32,
    "position": "QB",
    "contract_value": 40_000_000,
    "contract_years_left": 2
}

player_2 = {
    "name": "Young WR",
    "overall": 78,
    "potential": 91,
    "age": 23,
    "position": "WR",
    "contract_value": 6_000_000,
    "contract_years_left": 3
}

# Mock draft picks (use actual PICK_VALUE_CHART keys)
pick_1 = {
    "overall_pick": 15,  # 1st round
    "future_years_out": 0
}

pick_2 = {
    "overall_pick": 160,  # 5th round
    "future_years_out": 1
}

# Evaluate QB trade
print("---- Team A Acquiring Veteran QB from team B ----")
qb_value_to_A = calculate_player_value_debug(player_1, team_A_prefs)
pick_value_to_B = calculate_pick_value(pick_1["overall_pick"], team_B_prefs, pick_1["future_years_out"])
print(f"Pick {pick_1['overall_pick']} value: {PICK_VALUE_CHART.get(pick_1['overall_pick'])}")
delta_qb_trade = pick_value_to_B - qb_value_to_A
print(f"Trade Value Delta (A gives vs gets): {delta_qb_trade}")
decision_A = should_cpu_accept_trade(delta_qb_trade, team_B_context)
print(f"Team B {'ACCEPTS' if decision_A else 'REJECTS'} the trade\n")

# Evaluate WR trade
print("---- Team B Acquiring Young WR from team A ----")
wr_value_to_B = calculate_player_value_debug(player_2, team_B_prefs)
pick_value_to_A = calculate_pick_value(pick_2["overall_pick"], team_A_prefs, pick_2["future_years_out"])
print(f"Pick {pick_2['overall_pick']} value (future): {PICK_VALUE_CHART.get(pick_2['overall_pick'])}")
delta_wr_trade = pick_value_to_A - wr_value_to_B
print(f"Trade Value Delta (B gives vs gets): {delta_wr_trade}")
decision_B = should_cpu_accept_trade(delta_wr_trade, team_A_context)
print(f"Team A {'ACCEPTS' if decision_B else 'REJECTS'} the trade")
