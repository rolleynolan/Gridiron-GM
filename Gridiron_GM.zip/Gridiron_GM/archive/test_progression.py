import sys
import os

# Add project root to sys.path
CURRENT_DIR = os.path.dirname(os.path.abspath(__file__))
PROJECT_ROOT = os.path.abspath(os.path.join(CURRENT_DIR, "..", ".."))
sys.path.append(PROJECT_ROOT)

from engine.core.player_progression import progress_players

class MockPlayer:
    def __init__(self, name, overall, dev_curve, dev_rate, potential):
        self.name = name
        self.true_overall = overall
        self.dev_curve = dev_curve
        self.dev_rate = dev_rate
        self.potential = potential

class MockRoster:
    def __init__(self, players):
        self.players = players

# Create example players
players = [
    MockPlayer("Tyrone Willis", 68, "early", 1.05, 85),
    MockPlayer("Devon Carter", 72, "normal", 1.00, 90),
    MockPlayer("Michael Ellis", 75, "late", 0.95, 88),
    MockPlayer("Jalen Thomas", 81, "flat", 1.10, 82)
]

mock_team = MockRoster(players)

# Run progression
progress_players([mock_team])
