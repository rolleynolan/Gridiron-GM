import json

# Load your JSON file
with open("gridiron_gm/data/enriched_us_cities.json", "r", encoding="utf-8") as f:
    data = json.load(f)

# Extract city names using the 'name' key
city_names = [entry["name"] for entry in data if "name" in entry]

# Save to cities.txt
with open("cities.txt", "w", encoding="utf-8") as f:
    for city in city_names:
        f.write(city + "\n")